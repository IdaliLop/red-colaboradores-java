package consultora.red;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Grado de influencia de cada nodo (RF3).
 *
 * <p>Con la convención {@code u → v} = «u reporta a v»:</p>
 * <ul>
 *   <li><b>grado de salida</b> = a cuántas personas reporta el colaborador;</li>
 *   <li><b>grado de entrada</b> = cuántas personas le reportan (su «autoridad»);</li>
 *   <li><b>influencia total</b> = entrada + salida (conexiones directas totales).</li>
 * </ul>
 * <p>Un auto-lazo suma 1 a la entrada y 1 a la salida (convención del grafo dirigido).</p>
 *
 * <p>El grado de salida es el tamaño de la lista de adyacencia; el de entrada se obtiene en
 * una sola pasada sobre todas las listas. Complejidad: O(V + E) tiempo, O(V) espacio.</p>
 */
public final class Grados {

    private Grados() {
    }

    /**
     * Grados de un nodo.
     *
     * @param nodo    identificador
     * @param entrada grado de entrada
     * @param salida  grado de salida
     */
    public record GradoNodo(String nodo, int entrada, int salida) {
        /** @return grado total = entrada + salida */
        public int total() {
            return entrada + salida;
        }
    }

    /**
     * Calcula los grados de todos los nodos.
     *
     * @param g grafo
     * @return un registro por nodo, en orden de inserción
     */
    public static List<GradoNodo> calcular(Grafo g) {
        Map<String, Integer> entrada = new HashMap<>();
        for (String v : g.nodos()) {
            entrada.put(v, 0);
        }
        for (String v : g.nodos()) {
            for (String w : g.sucesores(v)) {
                entrada.merge(w, 1, Integer::sum);
            }
        }
        List<GradoNodo> r = new ArrayList<>(g.numNodos());
        for (String v : g.nodos()) {
            r.add(new GradoNodo(v, entrada.get(v), g.sucesores(v).size()));
        }
        return r;
    }

    /**
     * Ordena por influencia: total desc, luego entrada desc, luego nombre asc.
     *
     * @param g grafo
     * @return ranking de colaboradores
     */
    public static List<GradoNodo> ranking(Grafo g) {
        List<GradoNodo> r = calcular(g);
        r.sort(Comparator.comparingInt(GradoNodo::total).reversed()
                .thenComparing(Comparator.comparingInt(GradoNodo::entrada).reversed())
                .thenComparing(GradoNodo::nodo));
        return r;
    }
}
