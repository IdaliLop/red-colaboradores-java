package consultora.red;

import static consultora.red.GrafosPrueba.grafo;
import static consultora.red.GrafosPrueba.set;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.TreeSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class GrafoTest {

    @Test
    @DisplayName("agregarArista crea los nodos y mantiene entrada/salida consistentes")
    void aristaCreaNodosYConsistencia() {
        Grafo g = grafo("A>B", "A>C", "C>B");
        assertEquals(set("A", "B", "C"), new TreeSet<>(g.nodos()));
        assertEquals(3, g.numAristas());
        assertEquals(set("B", "C"), new TreeSet<>(g.sucesores("A")));
        assertEquals(set("A", "C"), new TreeSet<>(g.predecesores("B")));
    }

    @Test
    @DisplayName("aristas y nodos duplicados se ignoran")
    void duplicados() {
        Grafo g = new Grafo();
        assertTrue(g.agregarNodo("A"));
        assertFalse(g.agregarNodo("A"));
        assertTrue(g.agregarArista("A", "B"));
        assertFalse(g.agregarArista("A", "B"));
        assertEquals(1, g.numAristas());
        assertEquals(2, g.numNodos());
    }

    @Test
    @DisplayName("la vista no dirigida es simétrica y colapsa aristas mutuas")
    void vistaNoDirigida() {
        Grafo g = grafo("A>B", "B>A", "B>C");
        assertEquals(3, g.numAristas());
        assertEquals(2, g.numAristasNoDirigidas()); // {A,B} cuenta una sola vez
        assertEquals(set("A", "C"), new TreeSet<>(g.vecinos("B")));
        assertEquals(set("B"), new TreeSet<>(g.vecinos("A")));
    }

    @Test
    @DisplayName("la vista no dirigida se invalida al modificar el grafo")
    void cacheSeInvalida() {
        Grafo g = grafo("A>B");
        assertEquals(1, g.numAristasNoDirigidas());
        g.agregarArista("B", "C");
        assertEquals(2, g.numAristasNoDirigidas());
        assertEquals(set("A", "C"), new TreeSet<>(g.vecinos("B")));
    }

    @Test
    @DisplayName("el auto-lazo cuenta en la vista dirigida y se omite en la no dirigida")
    void autoLazo() {
        Grafo g = grafo("A>A", "A>B");
        assertTrue(g.tieneAutoLazo("A"));
        assertFalse(g.tieneAutoLazo("B"));
        assertEquals(2, g.numAristas());
        assertEquals(1, g.numAristasNoDirigidas());
        assertEquals(set("B"), new TreeSet<>(g.vecinos("A")));
        assertEquals(java.util.List.of("A"), g.autoLazos());
    }

    @Test
    @DisplayName("identificadores inválidos y nodos inexistentes lanzan excepción")
    void validaciones() {
        Grafo g = grafo("A>B");
        assertThrows(IllegalArgumentException.class, () -> g.agregarNodo(null));
        assertThrows(IllegalArgumentException.class, () -> g.agregarNodo("  "));
        assertThrows(IllegalArgumentException.class, () -> g.sucesores("Z"));
        assertThrows(IllegalArgumentException.class, () -> g.predecesores("Z"));
        assertThrows(IllegalArgumentException.class, () -> g.vecinos("Z"));
    }

    @Test
    @DisplayName("las vistas devueltas son de solo lectura")
    void vistasInmutables() {
        Grafo g = grafo("A>B");
        assertThrows(UnsupportedOperationException.class, () -> g.sucesores("A").add("X"));
        assertThrows(UnsupportedOperationException.class, () -> g.nodos().add("X"));
        assertThrows(UnsupportedOperationException.class, () -> g.vecinos("A").add("X"));
    }

    @Test
    @DisplayName("grafo vacío")
    void vacio() {
        Grafo g = new Grafo();
        assertTrue(g.estaVacio());
        assertEquals(0, g.numNodos());
        assertEquals(0, g.numAristas());
        assertEquals(0, g.numAristasNoDirigidas());
    }
}
