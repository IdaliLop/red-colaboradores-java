package consultora.red;

import static consultora.red.GrafosPrueba.aleatorio;
import static consultora.red.GrafosPrueba.dagAleatorio;
import static consultora.red.GrafosPrueba.esCaminoValido;
import static consultora.red.GrafosPrueba.grafo;
import static consultora.red.GrafosPrueba.longitudExhaustiva;
import static consultora.red.GrafosPrueba.set;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Random;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class GradosCaminoArticulacionTest {

    // ---------- Grados (RF3) ----------

    private static Grados.GradoNodo grado(Grafo g, String v) {
        return Grados.calcular(g).stream().filter(d -> d.nodo().equals(v)).findFirst().orElseThrow();
    }

    @Test
    @DisplayName("grados: valores esperados en una jerarquía pequeña")
    void gradosBasicos() {
        Grafo g = grafo("B>A", "C>A", "D>B", "E>B");
        assertEquals(new Grados.GradoNodo("A", 2, 0), grado(g, "A"));
        assertEquals(new Grados.GradoNodo("B", 2, 1), grado(g, "B"));
        assertEquals(new Grados.GradoNodo("D", 0, 1), grado(g, "D"));
        assertEquals(3, grado(g, "B").total());
    }

    @Test
    @DisplayName("grados: auto-lazo suma 1 a entrada y 1 a salida")
    void gradosAutoLazo() {
        Grafo g = grafo("A>A", "A>B");
        assertEquals(new Grados.GradoNodo("A", 1, 2), grado(g, "A"));
        assertEquals(new Grados.GradoNodo("B", 1, 0), grado(g, "B"));
    }

    @Test
    @DisplayName("grados: suma de entradas = suma de salidas = |E| y coincide con predecesores")
    void gradosInvariantes() {
        Random rnd = new Random(5);
        for (int t = 0; t < 200; t++) {
            Grafo g = aleatorio(rnd, 1 + rnd.nextInt(12), 0.2, true);
            int se = 0;
            int ss = 0;
            for (Grados.GradoNodo d : Grados.calcular(g)) {
                se += d.entrada();
                ss += d.salida();
                assertEquals(g.predecesores(d.nodo()).size(), d.entrada());
                assertEquals(g.sucesores(d.nodo()).size(), d.salida());
            }
            assertEquals(g.numAristas(), se);
            assertEquals(g.numAristas(), ss);
        }
    }

    @Test
    @DisplayName("grados: el ranking ordena por total, luego entrada, luego nombre")
    void ranking() {
        Grafo g = grafo("B>A", "C>A", "D>B", "E>B", "F>E");
        List<Grados.GradoNodo> r = Grados.ranking(g);
        assertEquals("B", r.get(0).nodo());   // total 3
        assertEquals("A", r.get(1).nodo());   // total 2, entrada 2
        assertEquals("E", r.get(2).nodo());   // total 2, entrada 1
        assertTrue(Grados.ranking(new Grafo()).isEmpty());
    }

    // ---------- Camino simple más largo (RF4) ----------

    @Test
    @DisplayName("camino: cadena lineal")
    void cadena() {
        Grafo g = grafo("A>B", "B>C", "C>D");
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(g, "A", "D", true).orElseThrow();
        assertEquals(List.of("A", "B", "C", "D"), r.camino());
        assertEquals(3, r.aristas());
    }

    @Test
    @DisplayName("camino: prefiere la ruta larga sobre la corta")
    void prefiereLarga() {
        Grafo g = grafo("A>B", "B>D", "A>C", "C>E", "E>D");
        assertEquals(3, CaminoMasLargo.buscar(g, "A", "D", true).orElseThrow().aristas());
    }

    @Test
    @DisplayName("camino: sin repetición de nodos aunque haya ciclos")
    void sinRepeticion() {
        Grafo g = grafo("A>B", "B>C", "C>A"); // ciclo dirigido
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(g, "A", "C", true).orElseThrow();
        assertEquals(List.of("A", "B", "C"), r.camino()); // no puede dar la vuelta completa
    }

    @Test
    @DisplayName("camino: el modo no dirigido puede ser más largo que el dirigido")
    void modoNoDirigido() {
        Grafo g = grafo("D>B", "B>A", "E>B", "E>C", "C>A", "H>D");
        // Dirigido H->D->B->A = 3.  No dirigido: H-D-B-E-C-A = 5.
        assertEquals(3, CaminoMasLargo.buscar(g, "H", "A", true).orElseThrow().aristas());
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(g, "H", "A", false).orElseThrow();
        assertEquals(5, r.aristas());
        assertTrue(esCaminoValido(g, r.camino(), "H", "A", false));
    }

    @Test
    @DisplayName("camino: origen = destino devuelve camino de longitud 0")
    void mismoNodo() {
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(grafo("A>B", "B>A"), "A", "A", true).orElseThrow();
        assertEquals(List.of("A"), r.camino());
        assertEquals(0, r.aristas());
    }

    @Test
    @DisplayName("camino: sin camino devuelve vacío (dirección opuesta y otra componente)")
    void sinCamino() {
        Grafo g = grafo("A>B", "X");
        assertTrue(CaminoMasLargo.buscar(g, "B", "A", true).isEmpty());
        assertTrue(CaminoMasLargo.buscar(g, "B", "A", false).isPresent());
        assertTrue(CaminoMasLargo.buscar(g, "A", "X", false).isEmpty());
    }

    @Test
    @DisplayName("camino: nodos inexistentes lanzan IllegalArgumentException")
    void nodosInexistentes() {
        Grafo g = grafo("A>B");
        assertThrows(IllegalArgumentException.class, () -> CaminoMasLargo.buscar(g, "Z", "A", true));
        assertThrows(IllegalArgumentException.class, () -> CaminoMasLargo.buscar(g, "A", "Z", true));
        assertThrows(IllegalArgumentException.class, () -> CaminoMasLargo.buscar(new Grafo(), "A", "B", true));
    }

    @Test
    @DisplayName("camino: el auto-lazo no afecta al camino")
    void autoLazo() {
        Grafo g = grafo("A>A", "A>B", "B>B");
        assertEquals(1, CaminoMasLargo.buscar(g, "A", "B", true).orElseThrow().aristas());
    }

    @Test
    @DisplayName("camino: grafo completo K6 no dirigido admite camino hamiltoniano (5 aristas)")
    void completo() {
        Grafo g = new Grafo();
        String[] n = {"a", "b", "c", "d", "e", "f"};
        for (int i = 0; i < n.length; i++) {
            for (int j = i + 1; j < n.length; j++) {
                g.agregarArista(n[i], n[j]);
            }
        }
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(g, "a", "f", false).orElseThrow();
        assertEquals(5, r.aristas());
        assertTrue(esCaminoValido(g, r.camino(), "a", "f", false));
    }

    @Test
    @DisplayName("camino: la poda NO altera el óptimo (comparado con búsqueda exhaustiva, ambos modos)")
    void podaEsSegura() {
        Random rnd = new Random(2024);
        for (int t = 0; t < 400; t++) {
            Grafo g = aleatorio(rnd, 2 + rnd.nextInt(8), 0.1 + rnd.nextDouble() * 0.3, true);
            String o = "n" + rnd.nextInt(g.numNodos());
            String d = "n" + rnd.nextInt(g.numNodos());
            for (boolean dirigido : new boolean[] {true, false}) {
                int esperado = longitudExhaustiva(g, o, d, dirigido);
                Optional<CaminoMasLargo.Resultado> r = CaminoMasLargo.buscar(g, o, d, dirigido);
                if (esperado < 0) {
                    assertTrue(r.isEmpty(), "no debía haber camino " + o + "->" + d);
                } else {
                    assertEquals(esperado, r.orElseThrow().aristas(), "óptimo distinto en " + g);
                    assertTrue(esCaminoValido(g, r.get().camino(), o, d, dirigido));
                }
            }
        }
    }

    @Test
    @DisplayName("camino: en DAG el backtracking coincide con la programación dinámica O(V+E)")
    void contraDagDp() {
        Random rnd = new Random(77);
        for (int t = 0; t < 300; t++) {
            Grafo g = dagAleatorio(rnd, 3 + rnd.nextInt(10), 0.35);
            String o = "n0";
            String d = "n" + (g.numNodos() - 1);
            OptionalInt dp = CaminoMasLargo.longitudEnDag(g, o, d);
            Optional<CaminoMasLargo.Resultado> bt = CaminoMasLargo.buscar(g, o, d, true);
            assertEquals(dp.isPresent(), bt.isPresent());
            if (dp.isPresent()) {
                assertEquals(dp.getAsInt(), bt.get().aristas());
            }
        }
    }

    @Test
    @DisplayName("camino: longitudEnDag rechaza grafos con ciclo")
    void dagConCiclo() {
        assertThrows(IllegalStateException.class, () -> CaminoMasLargo.longitudEnDag(grafo("A>B", "B>A"), "A", "B"));
    }

    @Test
    @DisplayName("camino: la poda reduce expansiones frente al factorial en un grafo con destino inalcanzable")
    void podaReduceTrabajo() {
        // K9 no dirigido + un nodo 'x' desconectado: sin poda se recorrerían ~109 600 caminos simples.
        Grafo g = new Grafo();
        for (int i = 0; i < 9; i++) {
            for (int j = i + 1; j < 9; j++) {
                g.agregarArista("k" + i, "k" + j);
            }
        }
        g.agregarNodo("x");
        assertTrue(CaminoMasLargo.buscar(g, "k0", "x", false).isEmpty());
        // Con destino alcanzable en K9, el primer camino hamiltoniano (8 aristas) ya es óptimo y se poda el resto.
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(g, "k0", "k8", false).orElseThrow();
        assertEquals(8, r.aristas());
        assertTrue(r.expansiones() < 100, "expansiones=" + r.expansiones());
    }

    // ---------- Puntos de articulación (RF5) ----------

    @Test
    @DisplayName("articulación: camino A-B-C-D → {B, C}")
    void articulacionCamino() {
        assertEquals(set("B", "C"), new java.util.TreeSet<>(PuntosArticulacion.encontrar(grafo("A>B", "C>B", "C>D"))));
    }

    @Test
    @DisplayName("articulación: estrella, el centro es el único punto")
    void estrella() {
        Grafo g = grafo("a>H", "b>H", "c>H", "d>H");
        assertEquals(Set.of("H"), PuntosArticulacion.encontrar(g));
        assertEquals(4, PuntosArticulacion.fragmentosAlEliminar(g, "H"));
    }

    @Test
    @DisplayName("articulación: un ciclo no tiene puntos de articulación")
    void cicloSinPuntos() {
        assertTrue(PuntosArticulacion.encontrar(grafo("A>B", "B>C", "C>D", "D>A")).isEmpty());
    }

    @Test
    @DisplayName("articulación: dos triángulos unidos por un nodo")
    void dosTriangulos() {
        Grafo g = grafo("A>B", "B>C", "C>A", "C>D", "D>E", "E>C");
        assertEquals(Set.of("C"), PuntosArticulacion.encontrar(g));
    }

    @Test
    @DisplayName("articulación: la raíz del DFS con un solo hijo no es punto")
    void raizHoja() {
        Grafo g = grafo("A>B", "B>C"); // A es el primer nodo (raíz) y es hoja
        assertEquals(Set.of("B"), PuntosArticulacion.encontrar(g));
    }

    @Test
    @DisplayName("articulación: varias componentes se procesan todas")
    void variasComponentes() {
        Grafo g = grafo("A>B", "B>C", "X>Y", "Y>Z", "Solo");
        assertEquals(Set.of("B", "Y"), PuntosArticulacion.encontrar(g));
    }

    @Test
    @DisplayName("articulación: auto-lazo y arista mutua no cambian el resultado")
    void autoLazoYMutua() {
        Grafo g = grafo("A>B", "B>A", "B>B", "B>C");
        assertEquals(Set.of("B"), PuntosArticulacion.encontrar(g));
    }

    @Test
    @DisplayName("articulación: Tarjan coincide con la definición por eliminación (aleatorio)")
    void tarjanContraFuerzaBruta() {
        Random rnd = new Random(31337);
        for (int t = 0; t < 500; t++) {
            Grafo g = aleatorio(rnd, 1 + rnd.nextInt(11), 0.05 + rnd.nextDouble() * 0.2, true);
            Set<String> esperado = new java.util.HashSet<>();
            for (String v : g.nodos()) {
                if (PuntosArticulacion.fragmentosAlEliminar(g, v) >= 2) {
                    esperado.add(v);
                }
            }
            assertEquals(esperado, PuntosArticulacion.encontrar(g), "discrepancia en " + g);
        }
    }

    @Test
    @DisplayName("articulación: red vacía y de un nodo")
    void vaciaYUnNodo() {
        assertTrue(PuntosArticulacion.encontrar(new Grafo()).isEmpty());
        assertTrue(PuntosArticulacion.encontrar(grafo("Solo")).isEmpty());
        assertEquals(0, PuntosArticulacion.fragmentosAlEliminar(grafo("Solo"), "Solo"));
        assertThrows(IllegalArgumentException.class, () -> PuntosArticulacion.fragmentosAlEliminar(new Grafo(), "X"));
    }

    @Test
    @DisplayName("articulación: cadena de 100 000 nodos no desborda la pila")
    void cadenaLarga() {
        Grafo g = new Grafo();
        for (int i = 0; i < 100_000; i++) {
            g.agregarArista("n" + i, "n" + (i + 1));
        }
        assertEquals(99_999, PuntosArticulacion.encontrar(g).size());
        assertFalse(PuntosArticulacion.encontrar(g).contains("n0"));
    }
}
