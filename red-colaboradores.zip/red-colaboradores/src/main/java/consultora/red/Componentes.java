package consultora.red;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Componentes conexas mediante BFS sobre la vista no dirigida (RF2).
 *
 * <p>Como el grafo base es dirigido, lo que se obtiene son las componentes
 * <em>débilmente</em> conexas: se ignora el sentido de las aristas, que es lo apropiado
 * para detectar «comunidades aisladas» de colaboradores.</p>
 *
 * <p>Complejidad: tiempo O(V + E), espacio O(V) (conjunto de visitados + cola).</p>
 */
public final class Componentes {

    private Componentes() {
    }

    /**
     * Calcula las comunidades aisladas.
     *
     * @param g grafo (puede estar vacío)
     * @return lista de componentes, de mayor a menor tamaño (empates: orden de descubrimiento);
     *         cada componente conserva el orden BFS. Lista vacía si el grafo no tiene nodos.
     */
    public static List<Set<String>> encontrar(Grafo g) {
        Set<String> visitados = new HashSet<>();
        List<Set<String>> resultado = new ArrayList<>();
        for (String inicio : g.nodos()) {
            if (!visitados.add(inicio)) {
                continue;
            }
            Set<String> componente = new LinkedHashSet<>();
            Deque<String> cola = new ArrayDeque<>();
            cola.add(inicio);
            while (!cola.isEmpty()) {
                String v = cola.poll();
                componente.add(v);
                for (String w : g.vecinos(v)) {
                    if (visitados.add(w)) { // add devuelve false si ya estaba: marca y comprueba a la vez
                        cola.add(w);
                    }
                }
            }
            resultado.add(componente);
        }
        resultado.sort(Comparator.<Set<String>>comparingInt(Set::size).reversed()); // sort estable
        return resultado;
    }
}
