package consultora.red;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Puntos de articulación («colaboradores puente») mediante el algoritmo de Tarjan /
 * Hopcroft–Tarjan sobre la vista no dirigida (RF5).
 *
 * <h2>Idea</h2>
 * <p>Para cada nodo se guarda {@code disc[v]} (orden de descubrimiento en el DFS) y
 * {@code low[v]} (el menor {@code disc} alcanzable desde el subárbol de {@code v} usando a
 * lo sumo una arista de retroceso). Un nodo {@code p} que no es raíz es punto de articulación
 * ⇔ tiene un hijo {@code v} del árbol DFS con {@code low[v] ≥ disc[p]} (el subárbol de
 * {@code v} no puede escapar de {@code p}). La raíz lo es ⇔ tiene ≥ 2 hijos en el árbol DFS.</p>
 *
 * <p>La implementación es iterativa (pila {@link ArrayDeque}) para evitar desbordar la pila
 * en redes largas. Se procesan todas las componentes. Como la vista derivada es un grafo
 * simple, omitir al padre <em>por nodo</em> es correcto (no hay aristas paralelas).</p>
 *
 * <p>Complejidad: tiempo O(V + E), espacio O(V).</p>
 */
public final class PuntosArticulacion {

    private PuntosArticulacion() {
    }

    private record Marco(String nodo, Iterator<String> pendientes) {
    }

    /**
     * Encuentra los nodos cuya eliminación aumenta el número de componentes.
     *
     * @param g grafo
     * @return conjunto de puntos de articulación (vacío si no hay)
     */
    public static Set<String> encontrar(Grafo g) {
        Map<String, Integer> disc = new HashMap<>();
        Map<String, Integer> low = new HashMap<>();
        Map<String, String> padre = new HashMap<>();
        Set<String> articulaciones = new HashSet<>();
        int reloj = 0;

        for (String raiz : g.nodos()) {
            if (disc.containsKey(raiz)) {
                continue;
            }
            int hijosRaiz = 0;
            reloj++;
            disc.put(raiz, reloj);
            low.put(raiz, reloj);
            Deque<Marco> pila = new ArrayDeque<>();
            pila.push(new Marco(raiz, g.vecinos(raiz).iterator()));

            while (!pila.isEmpty()) {
                Marco m = pila.peek();
                String v = m.nodo();
                if (m.pendientes().hasNext()) {
                    String w = m.pendientes().next();
                    if (!disc.containsKey(w)) {            // arista de árbol
                        padre.put(w, v);
                        reloj++;
                        disc.put(w, reloj);
                        low.put(w, reloj);
                        if (v.equals(raiz)) {
                            hijosRaiz++;
                        }
                        pila.push(new Marco(w, g.vecinos(w).iterator()));
                    } else if (!w.equals(padre.get(v))) {  // arista de retroceso
                        low.put(v, Math.min(low.get(v), disc.get(w)));
                    }
                } else {                                    // v terminado: propagar al padre
                    pila.pop();
                    String p = padre.get(v);
                    if (p != null) {
                        low.put(p, Math.min(low.get(p), low.get(v)));
                        if (!p.equals(raiz) && low.get(v) >= disc.get(p)) {
                            articulaciones.add(p);
                        }
                    }
                }
            }
            if (hijosRaiz > 1) {
                articulaciones.add(raiz);
            }
        }
        return articulaciones;
    }

    /**
     * Número de fragmentos en que queda dividida la componente de {@code v} al eliminarlo
     * (mide el «impacto» del colaborador puente). {@code v} es punto de articulación ⇔ el
     * resultado es ≥ 2. Costo O(V + E).
     *
     * @param g grafo
     * @param v nodo a eliminar
     * @return fragmentos resultantes (0 si {@code v} no tiene vecinos)
     * @throws IllegalArgumentException si {@code v} no existe
     */
    public static int fragmentosAlEliminar(Grafo g, String v) {
        Set<String> vistos = new HashSet<>();
        vistos.add(v);
        int fragmentos = 0;
        for (String inicio : g.vecinos(v)) { // lanza IllegalArgumentException si v no existe
            if (!vistos.add(inicio)) {
                continue;
            }
            fragmentos++;
            Deque<String> cola = new ArrayDeque<>();
            cola.add(inicio);
            while (!cola.isEmpty()) {
                String x = cola.poll();
                for (String w : g.vecinos(x)) {
                    if (vistos.add(w)) {
                        cola.add(w);
                    }
                }
            }
        }
        return fragmentos;
    }
}
