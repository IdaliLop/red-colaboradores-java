import consultora.red.*;
import java.util.*;

public class Bench {
    static long llamadas;
    static int exh(Grafo g, String v, String t, Set<String> vis) {
        llamadas++;
        if (v.equals(t)) return 0;
        int best = -1;
        for (String w : g.vecinos(v)) if (vis.add(w)) { int r = exh(g, w, t, vis); vis.remove(w); if (r >= 0) best = Math.max(best, r + 1); }
        return best;
    }
    static void caso(String nombre, Grafo g, String o, String d) {
        long t0 = System.nanoTime();
        CaminoMasLargo.Resultado r = CaminoMasLargo.buscar(g, o, d, false).orElseThrow();
        double ms = (System.nanoTime() - t0) / 1e6;
        String ex = "-";
        llamadas = 0;
        if (g.numNodos() <= 12 || nombre.startsWith("Rejilla 4x4")) {
            t0 = System.nanoTime();
            Set<String> vis = new HashSet<>(Set.of(o));
            int e = exh(g, o, d, vis);
            double ms2 = (System.nanoTime() - t0) / 1e6;
            ex = llamadas + " (" + String.format("%.1f", ms2) + " ms) long=" + e;
        }
        System.out.printf("%-26s n=%-3d aristas=%-3d long=%-3d | poda: %8d exp (%.2f ms) | sin poda: %s%n",
            nombre, g.numNodos(), g.numAristasNoDirigidas(), r.aristas(), r.expansiones(), ms, ex);
    }
    public static void main(String[] a) {
        for (int n = 6; n <= 11; n++) {
            Grafo g = new Grafo();
            for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) g.agregarArista("k" + i, "k" + j);
            caso("Completo K" + n, g, "k0", "k" + (n - 1));
        }
        for (int k : new int[]{3, 4, 5}) {
            Grafo g = new Grafo();
            for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) {
                if (i + 1 < k) g.agregarArista("r" + i + "_" + j, "r" + (i + 1) + "_" + j);
                if (j + 1 < k) g.agregarArista("r" + i + "_" + j, "r" + i + "_" + (j + 1));
            }
            caso("Rejilla " + k + "x" + k, g, "r0_0", "r" + (k - 1) + "_" + (k - 1));
        }
        Random rnd = new Random(1);
        for (int n : new int[]{10, 12, 14, 16, 18}) {
            Grafo g = new Grafo();
            for (int i = 0; i < n; i++) g.agregarNodo("n" + i);
            for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (rnd.nextDouble() < 3.0 / n) g.agregarArista("n" + i, "n" + j);
            Optional<CaminoMasLargo.Resultado> r = CaminoMasLargo.buscar(g, "n0", "n" + (n - 1), false);
            long t0 = System.nanoTime();
            r = CaminoMasLargo.buscar(g, "n0", "n" + (n - 1), false);
            double ms = (System.nanoTime() - t0) / 1e6;
            System.out.printf("Aleatorio (grado~3)        n=%-3d aristas=%-3d long=%-3s | poda: %8s exp (%.2f ms)%n",
               n, g.numAristasNoDirigidas(), r.map(x -> "" + x.aristas()).orElse("-"), r.map(x -> "" + x.expansiones()).orElse("-"), ms);
        }
        Grafo red = null;
        try { red = CargadorRed.cargar(java.nio.file.Path.of("data", "red.json")); } catch (Exception e) { throw new RuntimeException(e); }
        caso("Red de ejemplo Hugo-Ana", red, "Hugo", "Ana");
        // DAG grande: DP vs backtracking
        Grafo dag = new Grafo();
        int N = 200000; for (int i = 0; i < N; i++) { dag.agregarArista("v" + i, "v" + (i + 1)); if (i + 2 <= N) dag.agregarArista("v" + i, "v" + (i + 2)); }
        long t0 = System.nanoTime();
        int lp = CaminoMasLargo.longitudEnDag(dag, "v0", "v" + N).getAsInt();
        System.out.printf("DAG de %d nodos (DP O(V+E)): long=%d en %.0f ms%n", N + 1, lp, (System.nanoTime() - t0) / 1e6);
        // Tarjan / componentes / ciclos en grafo grande
        Grafo big = new Grafo(); Random r2 = new Random(3); int V = 200000;
        for (int i = 0; i < V; i++) big.agregarNodo("x" + i);
        for (int i = 0; i < 2 * V; i++) big.agregarArista("x" + r2.nextInt(V), "x" + r2.nextInt(V));
        t0 = System.nanoTime(); int c = Componentes.encontrar(big).size(); double tc = (System.nanoTime() - t0) / 1e6;
        t0 = System.nanoTime(); boolean cd = Ciclos.cicloDirigido(big).isPresent(); double tcd = (System.nanoTime() - t0) / 1e6;
        t0 = System.nanoTime(); int ap = PuntosArticulacion.encontrar(big).size(); double tap = (System.nanoTime() - t0) / 1e6;
        t0 = System.nanoTime(); Grados.calcular(big); double tg = (System.nanoTime() - t0) / 1e6;
        System.out.printf("Grafo aleatorio V=%d E=%d: componentes=%d (%.0f ms), ciclo dir=%b (%.0f ms), articulaciones=%d (%.0f ms), grados (%.0f ms)%n", V, big.numAristas(), c, tc, cd, tcd, ap, tap, tg);
    }
}
