package consultora.red;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Detección de ciclos con DFS <b>iterativo</b> (pila explícita con {@link ArrayDeque}, de modo
 * que redes muy profundas no provocan {@code StackOverflowError}) (RF2).
 *
 * <h2>Dirigido</h2>
 * <p>Coloreo de tres estados: blanco (no visitado), gris (en la pila de recursión actual),
 * negro (terminado). Existe un ciclo dirigido ⇔ el DFS encuentra una arista hacia un nodo
 * gris (arista de retroceso). Un auto-lazo {@code u → u} es un ciclo de longitud 1 y una
 * arista mutua {@code u → v, v → u} es un ciclo de longitud 2: ambos son jerarquías inválidas.</p>
 *
 * <h2>No dirigido</h2>
 * <p>Sobre la vista derivada (simple: sin aristas paralelas ni auto-lazos), existe un ciclo
 * ⇔ el DFS encuentra una arista hacia un nodo ya visitado que no sea el padre inmediato.
 * Dado que la vista colapsa {@code u → v} y {@code v → u} en una sola arista, esa pareja
 * <em>no</em> es un ciclo no dirigido (sí lo es en la vista dirigida). Un auto-lazo se
 * considera ciclo de longitud 1 también aquí.</p>
 *
 * <p>Complejidad de ambos: tiempo O(V + E), espacio O(V).</p>
 */
public final class Ciclos {

    private static final int GRIS = 1;
    private static final int NEGRO = 2;

    private Ciclos() {
    }

    /** Marco de la pila explícita: nodo y el iterador de sus vecinos pendientes. */
    private record Marco(String nodo, Iterator<String> pendientes) {
    }

    /**
     * Busca un ciclo en el grafo dirigido.
     *
     * @param g grafo
     * @return un ciclo como lista cerrada {@code [a, b, ..., a]} (siguiendo el sentido de las
     *         aristas), o vacío si el grafo es acíclico (un DAG)
     */
    public static Optional<List<String>> cicloDirigido(Grafo g) {
        Map<String, Integer> color = new HashMap<>(); // ausente = blanco
        Map<String, String> padre = new HashMap<>();
        for (String raiz : g.nodos()) {
            if (color.containsKey(raiz)) {
                continue;
            }
            Deque<Marco> pila = new ArrayDeque<>();
            color.put(raiz, GRIS);
            pila.push(new Marco(raiz, g.sucesores(raiz).iterator()));
            while (!pila.isEmpty()) {
                Marco m = pila.peek();
                if (m.pendientes().hasNext()) {
                    String w = m.pendientes().next();
                    Integer c = color.get(w);
                    if (c == null) {
                        color.put(w, GRIS);
                        padre.put(w, m.nodo());
                        pila.push(new Marco(w, g.sucesores(w).iterator()));
                    } else if (c == GRIS) {
                        return Optional.of(reconstruir(padre, m.nodo(), w));
                    }
                } else {
                    color.put(m.nodo(), NEGRO);
                    pila.pop();
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Busca un ciclo en la vista no dirigida (incluye auto-lazos).
     *
     * @param g grafo
     * @return un ciclo como lista cerrada {@code [a, ..., a]}, o vacío si el bosque es acíclico
     */
    public static Optional<List<String>> cicloNoDirigido(Grafo g) {
        for (String v : g.nodos()) {
            if (g.tieneAutoLazo(v)) {
                return Optional.of(List.of(v, v));
            }
        }
        Set<String> visitados = new HashSet<>();
        Map<String, String> padre = new HashMap<>();
        for (String raiz : g.nodos()) {
            if (!visitados.add(raiz)) {
                continue;
            }
            Deque<Marco> pila = new ArrayDeque<>();
            pila.push(new Marco(raiz, g.vecinos(raiz).iterator()));
            while (!pila.isEmpty()) {
                Marco m = pila.peek();
                if (m.pendientes().hasNext()) {
                    String w = m.pendientes().next();
                    if (visitados.add(w)) {
                        padre.put(w, m.nodo());
                        pila.push(new Marco(w, g.vecinos(w).iterator()));
                    } else if (!w.equals(padre.get(m.nodo()))) {
                        // En DFS no dirigido la primera arista no-árbol que se detecta
                        // siempre apunta a un ancestro de m.nodo().
                        return Optional.of(reconstruir(padre, m.nodo(), w));
                    }
                } else {
                    pila.pop();
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Reconstruye el ciclo {@code ancestro → ... → actual → ancestro} subiendo por los padres.
     */
    private static List<String> reconstruir(Map<String, String> padre, String actual, String ancestro) {
        List<String> ciclo = new ArrayList<>();
        String x = actual;
        ciclo.add(x);
        while (!x.equals(ancestro)) {
            x = padre.get(x);
            ciclo.add(x);
        }
        Collections.reverse(ciclo);   // [ancestro, ..., actual]
        ciclo.add(ancestro);          // cierra el ciclo
        return ciclo;
    }
}
