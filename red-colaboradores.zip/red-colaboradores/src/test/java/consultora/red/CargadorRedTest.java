package consultora.red;

import static consultora.red.GrafosPrueba.aristas;
import static consultora.red.GrafosPrueba.set;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.TreeSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CargadorRedTest {

    @Test
    @DisplayName("JSON: nodos, aristas y nodos aislados")
    void jsonBasico() {
        Grafo g = CargadorRed.desdeJson("""
                {"nodos": ["A", "B", "Solo"],
                 "aristas": [{"origen": "A", "destino": "B"}, {"origen": "B", "destino": "C"}]}
                """);
        assertEquals(set("A", "B", "C", "Solo"), new TreeSet<>(g.nodos())); // C se crea sola
        assertEquals(set("A>B", "B>C"), new TreeSet<>(aristas(g)));
    }

    @Test
    @DisplayName("JSON: objeto vacío o sin claves produce red vacía")
    void jsonVacio() {
        assertTrue(CargadorRed.desdeJson("{}").estaVacio());
        assertTrue(CargadorRed.desdeJson("{\"nodos\": [], \"aristas\": []}").estaVacio());
    }

    @Test
    @DisplayName("JSON: escapes, Unicode y BOM")
    void jsonEscapesYUnicode() {
        Grafo g = CargadorRed.desdeJson("\uFEFF{\"nodos\": [\"Jos\\u00e9\", \"Mu\u00f1oz\", \"Dos\\\"Q\"]}");
        assertEquals(set("José", "Muñoz", "Dos\"Q"), new TreeSet<>(g.nodos()));
    }

    @Test
    @DisplayName("JSON: auto-lazo se carga como arista dirigida")
    void jsonAutoLazo() {
        Grafo g = CargadorRed.desdeJson("{\"aristas\": [{\"origen\": \"A\", \"destino\": \"A\"}]}");
        assertTrue(g.tieneAutoLazo("A"));
    }

    @Test
    @DisplayName("JSON inválido lanza IllegalArgumentException con mensaje útil")
    void jsonInvalido() {
        String[] malos = {
            "", "[]", "{", "{\"nodos\": [\"A\",]}", "{\"nodos\": \"A\"}", "{\"nodos\": [1]}",
            "{\"aristas\": [{\"origen\": \"A\"}]}", "{\"aristas\": [5]}", "{\"aristas\": {}}",
            "{\"nodos\": [\"A\"]} basura", "{\"nodos\": [\"sin cerrar]}", "{nodos: []}",
            "{\"nodos\": [\"\"]}"
        };
        for (String m : malos) {
            assertThrows(IllegalArgumentException.class, () -> CargadorRed.desdeJson(m), "debía fallar: " + m);
        }
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> CargadorRed.desdeJson("{\n  \"nodos\": [\"A\",]\n}"));
        assertTrue(e.getMessage().contains("línea 2"), e.getMessage());
    }

    @Test
    @DisplayName("CSV: encabezado, comentarios, líneas en blanco y nodos aislados")
    void csvBasico() {
        Grafo g = CargadorRed.desdeCsv("""
                # comentario
                origen,destino

                A,B
                B , C
                Aislado,
                Otro
                """);
        assertEquals(set("A", "B", "C", "Aislado", "Otro"), new TreeSet<>(g.nodos()));
        assertEquals(set("A>B", "B>C"), new TreeSet<>(aristas(g)));
    }

    @Test
    @DisplayName("CSV: campos entre comillas con comas y comillas escapadas")
    void csvComillas() {
        Grafo g = CargadorRed.desdeCsv("\"Pérez, Ana\",\"Dir \"\"X\"\"\"\n");
        assertTrue(g.contieneArista("Pérez, Ana", "Dir \"X\""));
    }

    @Test
    @DisplayName("CSV vacío o solo encabezado produce red vacía")
    void csvVacio() {
        assertTrue(CargadorRed.desdeCsv("").estaVacio());
        assertTrue(CargadorRed.desdeCsv("origen,destino\n").estaVacio());
        assertTrue(CargadorRed.desdeCsv("\n\n# nada\n").estaVacio());
    }

    @Test
    @DisplayName("CSV inválido lanza IllegalArgumentException")
    void csvInvalido() {
        assertThrows(IllegalArgumentException.class, () -> CargadorRed.desdeCsv("A,B,C"));
        assertThrows(IllegalArgumentException.class, () -> CargadorRed.desdeCsv(",B"));
        assertThrows(IllegalArgumentException.class, () -> CargadorRed.desdeCsv("\"A,B"));
    }

    @Test
    @DisplayName("los archivos de ejemplo red.json y red.csv describen la misma red")
    void ejemplosEquivalentes() throws IOException {
        Grafo j = CargadorRed.cargar(Path.of("data", "red.json"));
        Grafo c = CargadorRed.cargar(Path.of("data", "red.csv"));
        assertEquals(16, j.numNodos());
        assertEquals(15, j.numAristas());
        assertEquals(new TreeSet<>(j.nodos()), new TreeSet<>(c.nodos()));
        assertEquals(aristas(j), aristas(c));
    }

    @Test
    @DisplayName("cargar(Path): extensión no soportada y archivo inexistente")
    void cargarErrores() throws IOException {
        assertThrows(IllegalArgumentException.class, () -> CargadorRed.cargar(Path.of("red.xml")));
        assertThrows(IOException.class, () -> CargadorRed.cargar(Path.of("no-existe-" + System.nanoTime() + ".json")));
    }

    @Test
    @DisplayName("cargar(Path) lee archivos UTF-8 temporales de ambos formatos")
    void cargarArchivosTemporales() throws IOException {
        Path json = Files.createTempFile("red", ".json");
        Path csv = Files.createTempFile("red", ".csv");
        try {
            Files.writeString(json, "{\"aristas\":[{\"origen\":\"Óscar\",\"destino\":\"Ñandú\"}]}");
            Files.writeString(csv, "Óscar,Ñandú\n");
            assertTrue(CargadorRed.cargar(json).contieneArista("Óscar", "Ñandú"));
            assertTrue(CargadorRed.cargar(csv).contieneArista("Óscar", "Ñandú"));
        } finally {
            Files.deleteIfExists(json);
            Files.deleteIfExists(csv);
        }
    }
}
