package consultora.red;

import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/** Constructores y oráculos auxiliares para las pruebas (no forma parte del código productivo). */
final class GrafosPrueba {

    private GrafosPrueba() {
    }

    /**
     * Construye un grafo desde especificaciones de texto: {@code "A>B"} es la arista A→B y
     * {@code "A"} declara un nodo aislado.
     */
    static Grafo grafo(String... specs) {
        Grafo g = new Grafo();
        for (String s : specs) {
            if (s.contains(">")) {
                String[] p = s.split(">");
                g.agregarArista(p[0], p[1]);
            } else {
                g.agregarNodo(s);
            }
        }
        return g;
    }

    /** Conjunto ordenado, cómodo para comparar. */
    static Set<String> set(String... xs) {
        return new TreeSet<>(List.of(xs));
    }

    /** Aristas dirigidas como cadenas "A>B". */
    static Set<String> aristas(Grafo g) {
        Set<String> r = new HashSet<>();
        for (String v : g.nodos()) {
            for (String w : g.sucesores(v)) {
                r.add(v + ">" + w);
            }
        }
        return r;
    }

    /** Grafo aleatorio dirigido con n nodos "n0..n(n-1)" y probabilidad p por par ordenado. */
    static Grafo aleatorio(Random rnd, int n, double p, boolean permitirAutoLazos) {
        Grafo g = new Grafo();
        for (int i = 0; i < n; i++) {
            g.agregarNodo("n" + i);
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if ((i != j || permitirAutoLazos) && rnd.nextDouble() < p) {
                    g.agregarArista("n" + i, "n" + j);
                }
            }
        }
        return g;
    }

    /** DAG aleatorio: solo aristas i→j con i<j. */
    static Grafo dagAleatorio(Random rnd, int n, double p) {
        Grafo g = new Grafo();
        for (int i = 0; i < n; i++) {
            g.agregarNodo("n" + i);
        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (rnd.nextDouble() < p) {
                    g.agregarArista("n" + i, "n" + j);
                }
            }
        }
        return g;
    }

    /** Verifica que {@code camino} es simple, comienza/termina donde se espera y usa aristas existentes. */
    static boolean esCaminoValido(Grafo g, List<String> camino, String origen, String destino, boolean dirigido) {
        if (camino.isEmpty() || !camino.get(0).equals(origen) || !camino.get(camino.size() - 1).equals(destino)) {
            return false;
        }
        if (new HashSet<>(camino).size() != camino.size()) {
            return false; // nodo repetido
        }
        for (int i = 0; i + 1 < camino.size(); i++) {
            String a = camino.get(i);
            String b = camino.get(i + 1);
            boolean existe = dirigido ? g.contieneArista(a, b) : (g.contieneArista(a, b) || g.contieneArista(b, a));
            if (!existe) {
                return false;
            }
        }
        return true;
    }

    /** Oráculo: búsqueda exhaustiva SIN poda. Devuelve la longitud máxima o -1 si no hay camino. */
    static int longitudExhaustiva(Grafo g, String origen, String destino, boolean dirigido) {
        return exhaustiva(g, origen, destino, dirigido, new HashSet<>(Set.of(origen)));
    }

    private static int exhaustiva(Grafo g, String v, String destino, boolean dirigido, Set<String> visitados) {
        if (v.equals(destino)) {
            return 0;
        }
        int mejor = -1;
        for (String w : dirigido ? g.sucesores(v) : g.vecinos(v)) {
            if (visitados.add(w)) {
                int r = exhaustiva(g, w, destino, dirigido, visitados);
                visitados.remove(w);
                if (r >= 0) {
                    mejor = Math.max(mejor, r + 1);
                }
            }
        }
        return mejor;
    }

    /** Oráculo: ¿es acíclico el grafo dirigido? (algoritmo de Kahn, independiente del DFS). */
    static boolean esAciclicoKahn(Grafo g) {
        java.util.Map<String, Integer> indeg = new java.util.HashMap<>();
        for (String v : g.nodos()) {
            indeg.put(v, g.predecesores(v).size());
        }
        java.util.ArrayDeque<String> cola = new java.util.ArrayDeque<>();
        indeg.forEach((k, d) -> {
            if (d == 0) {
                cola.add(k);
            }
        });
        int procesados = 0;
        while (!cola.isEmpty()) {
            String v = cola.poll();
            procesados++;
            for (String w : g.sucesores(v)) {
                if (indeg.merge(w, -1, Integer::sum) == 0) {
                    cola.add(w);
                }
            }
        }
        return procesados == g.numNodos();
    }
}
