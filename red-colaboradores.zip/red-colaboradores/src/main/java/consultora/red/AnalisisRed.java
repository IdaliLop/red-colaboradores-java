package consultora.red;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Resultado agregado de los análisis independientes del par de nodos (puntos 1, 2, 3 y 4 del
 * caso práctico). El camino más largo se calcula aparte porque depende del par consultado.
 *
 * @param grafo               red analizada
 * @param componentes         comunidades aisladas (mayor a menor)
 * @param cicloDirigido       un ciclo de dependencia (jerarquía inválida), si existe
 * @param cicloNoDirigido     un ciclo en la vista no dirigida, si existe
 * @param grados              grados de entrada/salida en orden de inserción
 * @param ranking             grados ordenados por influencia
 * @param puntosArticulacion  colaboradores puente
 */
public record AnalisisRed(
        Grafo grafo,
        List<Set<String>> componentes,
        Optional<List<String>> cicloDirigido,
        Optional<List<String>> cicloNoDirigido,
        List<Grados.GradoNodo> grados,
        List<Grados.GradoNodo> ranking,
        Set<String> puntosArticulacion) {

    /**
     * Ejecuta todos los análisis sobre el grafo.
     *
     * @param g grafo (puede estar vacío)
     * @return resultados
     */
    public static AnalisisRed analizar(Grafo g) {
        return new AnalisisRed(
                g,
                Componentes.encontrar(g),
                Ciclos.cicloDirigido(g),
                Ciclos.cicloNoDirigido(g),
                Grados.calcular(g),
                Grados.ranking(g),
                PuntosArticulacion.encontrar(g));
    }
}
