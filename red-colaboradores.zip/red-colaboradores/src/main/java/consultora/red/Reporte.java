package consultora.red;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Genera la salida tabulada (consola) y exporta {@code resultados.txt} (RF6).
 *
 * <p>El mismo texto se imprime en consola y se escribe al archivo, de modo que ambos son
 * idénticos por construcción.</p>
 */
public final class Reporte {

    private static final String LINEA = "=".repeat(78);

    private Reporte() {
    }

    /**
     * Consulta de camino más largo entre dos nodos.
     *
     * @param origen  nodo inicial
     * @param destino nodo final
     */
    public record Par(String origen, String destino) {
    }

    /**
     * Construye el reporte completo.
     *
     * @param fuente descripción del origen de los datos (p. ej. la ruta del archivo)
     * @param a      análisis ya calculado
     * @param pares  pares para los que se calcula el camino simple más largo (puede ser vacío)
     * @return texto del reporte
     * @throws IllegalArgumentException si algún par menciona un nodo inexistente
     */
    public static String generar(String fuente, AnalisisRed a, List<Par> pares) {
        Grafo g = a.grafo();
        StringBuilder sb = new StringBuilder();

        sb.append(LINEA).append('\n');
        sb.append(" ANÁLISIS DE LA RED DE COLABORADORES\n");
        sb.append(LINEA).append('\n');
        sb.append("Fuente de datos : ").append(fuente).append('\n');
        sb.append(String.format("Nodos           : %d\n", g.numNodos()));
        sb.append(String.format("Aristas         : %d dirigidas | %d no dirigidas (derivadas) | %d auto-lazos\n",
                g.numAristas(), g.numAristasNoDirigidas(), g.autoLazos().size()));
        sb.append("Convención      : A -> B  significa  \"A reporta a B\"\n\n");

        // 1. Componentes
        sb.append("1. COMUNIDADES AISLADAS (componentes conexas, BFS)\n");
        if (a.componentes().isEmpty()) {
            sb.append("   (la red está vacía: 0 componentes)\n");
        } else {
            List<String[]> filas = new ArrayList<>();
            int k = 1;
            for (Set<String> c : a.componentes()) {
                filas.add(new String[] {String.valueOf(k++), String.valueOf(c.size()), unir(c, ", ")});
            }
            sb.append(tabla(new String[] {"#", "Tamaño", "Miembros"}, filas, new boolean[] {true, true, false}));
            sb.append(String.format("   Total de componentes: %d\n", a.componentes().size()));
        }
        sb.append('\n');

        // 2. Ciclos
        sb.append("2. DETECCIÓN DE CICLOS (DFS)\n");
        sb.append(cicloTexto("Dependencias (dirigido)", a.cicloDirigido(),
                "JERARQUÍA INVÁLIDA: existe una cadena circular de reporte",
                "jerarquía válida (grafo dirigido acíclico)"));
        sb.append(cicloTexto("Relaciones (no dirigido)", a.cicloNoDirigido(),
                "existe un bucle de relaciones (redundancia de rutas)",
                "la red es un bosque (sin bucles)"));
        if (!g.autoLazos().isEmpty()) {
            sb.append("   Auto-lazos (alguien se reporta a sí mismo): ").append(unir(g.autoLazos(), ", ")).append('\n');
        }
        sb.append('\n');

        // 3. Grados
        sb.append("3. GRADO DE INFLUENCIA (ordenado por entrada + salida)\n");
        if (a.ranking().isEmpty()) {
            sb.append("   (sin nodos)\n");
        } else {
            List<String[]> filas = new ArrayList<>();
            for (Grados.GradoNodo d : a.ranking()) {
                filas.add(new String[] {d.nodo(), String.valueOf(d.entrada()),
                        String.valueOf(d.salida()), String.valueOf(d.total())});
            }
            sb.append(tabla(new String[] {"Colaborador", "Entrada", "Salida", "Total"}, filas,
                    new boolean[] {false, true, true, true}));
            sb.append("   Entrada = personas que le reportan | Salida = personas a quienes reporta\n");
        }
        sb.append('\n');

        // 4. Camino más largo
        sb.append("4. CAMINO SIMPLE MÁS LARGO (backtracking con poda; NP-difícil en general)\n");
        if (pares.isEmpty()) {
            sb.append("   (no se indicó ningún par; use --par ORIGEN DESTINO)\n");
        }
        for (Par p : pares) {
            sb.append(String.format("   Par: %s -> %s\n", p.origen(), p.destino()));
            List<String[]> filas = new ArrayList<>();
            for (boolean dirigido : new boolean[] {true, false}) {
                Optional<CaminoMasLargo.Resultado> r =
                        CaminoMasLargo.buscar(g, p.origen(), p.destino(), dirigido);
                String modo = dirigido ? "Dirigido" : "No dirigido";
                if (r.isPresent()) {
                    filas.add(new String[] {modo, String.valueOf(r.get().aristas()),
                            unir(r.get().camino(), " -> "), String.valueOf(r.get().expansiones())});
                } else {
                    filas.add(new String[] {modo, "-", "sin camino", "-"});
                }
            }
            sb.append(tabla(new String[] {"Modo", "Aristas", "Camino", "Expansiones"}, filas,
                    new boolean[] {false, true, false, true}));
        }
        sb.append('\n');

        // 5. Puntos de articulación
        sb.append("5. COLABORADORES PUENTE (puntos de articulación, Tarjan)\n");
        if (a.puntosArticulacion().isEmpty()) {
            sb.append("   Ninguno: la eliminación de un solo colaborador no desconecta la red.\n");
        } else {
            List<String> orden = new ArrayList<>(a.puntosArticulacion());
            Collections.sort(orden);
            List<String[]> filas = new ArrayList<>();
            for (String v : orden) {
                filas.add(new String[] {v, String.valueOf(g.vecinos(v).size()),
                        String.valueOf(PuntosArticulacion.fragmentosAlEliminar(g, v))});
            }
            sb.append(tabla(new String[] {"Colaborador puente", "Vecinos", "Fragmentos al eliminarlo"}, filas,
                    new boolean[] {false, true, true}));
            sb.append(String.format("   Total de puentes: %d\n", orden.size()));
        }
        sb.append(LINEA).append('\n');
        return sb.toString();
    }

    /**
     * Escribe el reporte en un archivo UTF-8, creando los directorios padre si hace falta.
     *
     * @param texto contenido
     * @param ruta  destino (p. ej. {@code resultados.txt})
     * @throws IOException si falla la escritura
     */
    public static void exportar(String texto, Path ruta) throws IOException {
        Path padre = ruta.toAbsolutePath().getParent();
        if (padre != null) {
            Files.createDirectories(padre);
        }
        Files.writeString(ruta, texto, StandardCharsets.UTF_8);
    }

    private static String cicloTexto(String etiqueta, Optional<List<String>> ciclo, String si, String no) {
        String cabecera = String.format("   %-26s: ", etiqueta);
        if (ciclo.isPresent()) {
            return cabecera + "SÍ  " + unir(ciclo.get(), " -> ") + "\n"
                    + String.format("   %-26s  => %s\n", "", si);
        }
        return cabecera + "NO  => " + no + "\n";
    }

    private static String unir(Iterable<String> it, String sep) {
        return String.join(sep, it);
    }

    /** Dibuja una tabla ASCII; las columnas marcadas en {@code derecha} se alinean a la derecha. */
    private static String tabla(String[] enc, List<String[]> filas, boolean[] derecha) {
        int[] w = new int[enc.length];
        for (int c = 0; c < enc.length; c++) {
            w[c] = enc[c].length();
            for (String[] f : filas) {
                w[c] = Math.max(w[c], f[c].length());
            }
        }
        StringBuilder sb = new StringBuilder();
        String sep = separador(w);
        sb.append(sep);
        sb.append(fila(enc, w, new boolean[enc.length]));
        sb.append(sep);
        for (String[] f : filas) {
            sb.append(fila(f, w, derecha));
        }
        sb.append(sep);
        return sb.toString();
    }

    private static String separador(int[] w) {
        StringBuilder sb = new StringBuilder("   +");
        for (int ancho : w) {
            sb.append("-".repeat(ancho + 2)).append('+');
        }
        return sb.append('\n').toString();
    }

    private static String fila(String[] celdas, int[] w, boolean[] derecha) {
        StringBuilder sb = new StringBuilder("   |");
        for (int c = 0; c < celdas.length; c++) {
            String fmt = derecha[c] ? " %" + w[c] + "s |" : " %-" + w[c] + "s |";
            sb.append(String.format(fmt, celdas[c]));
        }
        return sb.append('\n').toString();
    }
}
