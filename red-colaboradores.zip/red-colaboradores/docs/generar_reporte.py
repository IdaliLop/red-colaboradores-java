#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Genera reporte.pdf del examen práctico.

Uso (desde la raíz del repositorio):
    pip install reportlab matplotlib
    python3 docs/generar_reporte.py

Edita las constantes NOMBRE, REGISTRO, FECHA antes de generar.
Las cifras de pruebas se leen directamente de src/test; las de eficiencia son
las medidas con docs/Bench.java (ver sección 9 del reporte).
"""
import os
import re
import glob

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether, PageBreak,
                                PageTemplate, Paragraph, Preformatted, Spacer, Table, TableStyle)

# ----------------------------------------------------------------------------------------
NOMBRE = "______________________________"
REGISTRO = "______________"
FECHA = "23 de octubre de 2026"
# ----------------------------------------------------------------------------------------

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(RAIZ, "docs")
SALIDA = os.path.join(RAIZ, "reporte.pdf")

# ---------------------------------------------------------------- fuentes
D = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("DV", D + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DV-B", D + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DV-I", D + "DejaVuSans-Oblique.ttf"))
pdfmetrics.registerFont(TTFont("DV-BI", D + "DejaVuSans-BoldOblique.ttf"))
pdfmetrics.registerFont(TTFont("DVM", D + "DejaVuSansMono.ttf"))
pdfmetrics.registerFont(TTFont("DVM-B", D + "DejaVuSansMono-Bold.ttf"))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-BI")
pdfmetrics.registerFontFamily("DVM", normal="DVM", bold="DVM-B", italic="DVM", boldItalic="DVM-B")

AZUL = colors.HexColor("#1F3A5F")
AZUL_CLARO = colors.HexColor("#E8EEF6")
GRIS = colors.HexColor("#F4F4F4")
LINEA = colors.HexColor("#B8C2D0")

# ---------------------------------------------------------------- estilos
base = ParagraphStyle("base", fontName="DV", fontSize=9.3, leading=13.4, alignment=TA_JUSTIFY,
                      spaceAfter=5)
h1 = ParagraphStyle("h1", parent=base, fontName="DV-B", fontSize=14, leading=18, textColor=AZUL,
                    spaceBefore=12, spaceAfter=6, alignment=0, keepWithNext=1)
h2 = ParagraphStyle("h2", parent=base, fontName="DV-B", fontSize=11, leading=15, textColor=AZUL,
                    spaceBefore=8, spaceAfter=4, alignment=0, keepWithNext=1)
h3 = ParagraphStyle("h3", parent=base, fontName="DV-B", fontSize=9.6, leading=13, spaceBefore=4,
                    spaceAfter=2, alignment=0, keepWithNext=1)
cel = ParagraphStyle("cel", parent=base, fontSize=8.2, leading=10.6, alignment=0, spaceAfter=0)
celb = ParagraphStyle("celb", parent=cel, fontName="DV-B", textColor=colors.white)
nota = ParagraphStyle("nota", parent=base, fontSize=8, leading=10.5, textColor=colors.HexColor("#444444"),
                      alignment=0)
cod = ParagraphStyle("cod", fontName="DVM", fontSize=7.5, leading=9.6, backColor=GRIS,
                     borderColor=LINEA, borderWidth=0.5, borderPadding=5, spaceBefore=4, spaceAfter=9,
                     leftIndent=6, rightIndent=6)
tit = ParagraphStyle("tit", parent=base, fontName="DV-B", fontSize=22, leading=27, textColor=AZUL,
                     alignment=TA_CENTER, spaceAfter=8)
sub = ParagraphStyle("sub", parent=base, fontSize=12, leading=16, alignment=TA_CENTER,
                     textColor=colors.HexColor("#333333"))


def P(t, s=base):
    return Paragraph(t, s)


def C(t):
    return Preformatted(t.strip("\n"), cod)


def tabla(filas, anchos, cabecera=True, estilo_extra=None):
    datos = []
    for i, f in enumerate(filas):
        datos.append([Paragraph(str(c), celb if (cabecera and i == 0) else cel) for c in f])
    t = Table(datos, colWidths=anchos, repeatRows=1 if cabecera else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, LINEA), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if cabecera:
        st.append(("BACKGROUND", (0, 0), (-1, 0), AZUL))
        for r in range(1, len(filas)):
            if r % 2 == 0:
                st.append(("BACKGROUND", (0, r), (-1, r), AZUL_CLARO))
    if estilo_extra:
        st += estilo_extra
    t.setStyle(TableStyle(st))
    return t


def sp(h=6):
    return Spacer(1, h)


# ---------------------------------------------------------------- figuras
def figura_red():
    pos = {
        "Ana": (0, 5), "Beto": (-2.3, 3.8), "Carla": (2.3, 3.8), "Diego": (-3.8, 2.4),
        "Elena": (-0.8, 2.4), "Hugo": (-3.8, 0.9), "Irene": (-0.8, 0.9), "Fabián": (1.3, 2.2),
        "Gloria": (3.7, 2.4), "Jorge": (3.9, 0.7), "Karla": (2.6, -0.8), "Luis": (5.2, -0.8),
        "Marta": (8.6, 3.2), "Nora": (7.4, 1.6), "Óscar": (9.8, 1.6), "Paula": (8.6, -0.2),
    }
    aristas = [("Beto", "Ana"), ("Carla", "Ana"), ("Diego", "Beto"), ("Elena", "Beto"), ("Elena", "Carla"),
               ("Fabián", "Carla"), ("Gloria", "Carla"), ("Hugo", "Diego"), ("Irene", "Elena"),
               ("Jorge", "Gloria"), ("Jorge", "Karla"), ("Karla", "Luis"), ("Luis", "Jorge"),
               ("Nora", "Marta"), ("Óscar", "Marta")]
    ciclo = {("Jorge", "Karla"), ("Karla", "Luis"), ("Luis", "Jorge")}
    puentes = {"Beto", "Carla", "Diego", "Elena", "Gloria", "Jorge", "Marta"}

    fig, ax = plt.subplots(figsize=(10.2, 5.6))
    ax.set_aspect("equal")
    ax.axis("off")
    for (x0, y0, x1, y1, txt) in [(-5.0, -1.9, 6.4, 6.0, "Comunidad 1 (12 colaboradores)"),
                                  (6.4, 1.0, 11.0, 4.3, "Comunidad 2 (3)"),
                                  (7.3, -1.2, 9.9, 0.6, "Comunidad 3 (1)")]:
        ax.add_patch(FancyBboxPatch((x0, y0), x1 - x0, y1 - y0, boxstyle="round,pad=0.05,rounding_size=0.3",
                                    fill=False, ec="#7A869A", ls="--", lw=1.1))
        ax.text(x0 + 0.15, y1 - 0.25, txt, fontsize=8.5, color="#4A5568", va="top", style="italic")
    for o, d in aristas:
        col = "#C62828" if (o, d) in ciclo else "#455A64"
        ax.add_patch(FancyArrowPatch(pos[o], pos[d], arrowstyle="-|>", mutation_scale=13, shrinkA=17,
                                     shrinkB=17, color=col, lw=2.0 if (o, d) in ciclo else 1.3))
    for n, (x, y) in pos.items():
        ax.add_patch(Circle((x, y), 0.46, fc="#F5A623" if n in puentes else "#CFE3F7", ec="#1F3A5F", lw=1.3,
                            zorder=3))
        ax.text(x, y, n, ha="center", va="center", fontsize=7.6, zorder=4, fontweight="bold",
                color="#111111")
    ax.set_xlim(-5.2, 11.2)
    ax.set_ylim(-2.2, 6.3)
    leyenda = [plt.Line2D([0], [0], marker="o", color="w", mfc="#F5A623", mec="#1F3A5F", ms=11,
                          label="Colaborador puente (punto de articulación)"),
               plt.Line2D([0], [0], marker="o", color="w", mfc="#CFE3F7", mec="#1F3A5F", ms=11,
                          label="Colaborador regular"),
               plt.Line2D([0], [0], color="#C62828", lw=2.2, label="Ciclo de dependencia (jerarquía inválida)"),
               plt.Line2D([0], [0], color="#455A64", lw=1.3, label="«A reporta a B» (A → B)")]
    ax.legend(handles=leyenda, loc="lower left", bbox_to_anchor=(0.0, -0.02), fontsize=8, frameon=True)
    fig.tight_layout()
    ruta = os.path.join(FIG, "fig_red.png")
    fig.savefig(ruta, dpi=200)
    plt.close(fig)
    return ruta


def figura_poda():
    n = [6, 7, 8, 9, 10, 11]
    sin = [130, 652, 3914, 27400, 219202, 1972820]
    con = [16, 22, 29, 37, 46, 56]
    fig, ax = plt.subplots(figsize=(7.2, 3.3))
    w = 0.38
    xs = range(len(n))
    ax.bar([x - w / 2 for x in xs], sin, w, label="Búsqueda exhaustiva (sin poda)", color="#B0BEC5", ec="#37474F")
    ax.bar([x + w / 2 for x in xs], con, w, label="Backtracking con poda", color="#F5A623", ec="#37474F")
    ax.set_yscale("log")
    ax.set_xticks(list(xs))
    ax.set_xticklabels([f"K{k}" for k in n])
    ax.set_ylabel("Nodos expandidos (escala log)")
    ax.set_xlabel("Grafo completo K$_n$, camino entre dos nodos fijos")
    for x, v in zip(xs, sin):
        ax.text(x - w / 2, v * 1.15, f"{v:,}", ha="center", fontsize=6.8)
    for x, v in zip(xs, con):
        ax.text(x + w / 2, v * 1.15, str(v), ha="center", fontsize=6.8)
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(axis="y", ls=":", alpha=.5)
    fig.tight_layout()
    ruta = os.path.join(FIG, "fig_poda.png")
    fig.savefig(ruta, dpi=200)
    plt.close(fig)
    return ruta


# ---------------------------------------------------------------- datos reales del repositorio
def contar_pruebas():
    r = {}
    for f in sorted(glob.glob(os.path.join(RAIZ, "src/test/java/consultora/red/*Test.java"))):
        r[os.path.basename(f)[:-5]] = len(re.findall(r"^\s*@Test\b", open(f, encoding="utf-8").read(), re.M))
    return r


def contar_lineas(patron):
    return sum(len(open(f, encoding="utf-8").read().splitlines()) for f in glob.glob(os.path.join(RAIZ, patron)))


# ---------------------------------------------------------------- pie de página
def pie(canvas, doc):
    canvas.saveState()
    canvas.setFont("DV", 7.5)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawString(2.2 * cm, 1.3 * cm, "Estructuras de Datos y Algoritmia – Examen práctico, segundo parcial")
    canvas.drawRightString(letter[0] - 2.2 * cm, 1.3 * cm, f"Pág. {doc.page}")
    canvas.setStrokeColor(LINEA)
    canvas.line(2.2 * cm, 1.65 * cm, letter[0] - 2.2 * cm, 1.65 * cm)
    canvas.restoreState()


# ---------------------------------------------------------------- contenido
def construir():
    pruebas = contar_pruebas()
    total = sum(pruebas.values())
    lin_main = contar_lineas("src/main/java/consultora/red/*.java")
    lin_test = contar_lineas("src/test/java/consultora/red/*.java")
    f_red = figura_red()
    f_poda = figura_poda()
    W = letter[0] - 4.4 * cm  # ancho útil
    s = []

    # ------------------------------------------------ portada
    s += [sp(70), P("Análisis de redes de colaboradores<br/>mediante algoritmos sobre grafos", tit),
          P("Componentes conexas · Ciclos · Grados de influencia · Camino simple más largo · Puntos de articulación", sub),
          sp(30), P("<b>Examen práctico – Segundo parcial</b><br/>Estructuras de Datos y Algoritmia", sub), sp(40)]
    ficha = Table([[P("<b>Registro:</b>", cel), P(REGISTRO, cel), P("<b>Cal.:</b>", cel), P("________", cel)],
                   [P("<b>Nombre:</b>", cel), P(NOMBRE, cel), P("<b>Fecha:</b>", cel), P(FECHA, cel)]],
                  colWidths=[2.3 * cm, 8.2 * cm, 1.8 * cm, 4.4 * cm])
    ficha.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, LINEA), ("INNERGRID", (0, 0), (-1, -1), 0.3, LINEA),
                               ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    s += [ficha, sp(40),
          P(f"<b>Repositorio:</b> <font name='DVM'>red-colaboradores/</font> · Java 17+ · solo <font name='DVM'>java.util</font><br/>"
            f"<b>Código:</b> {lin_main} líneas en 11 clases · <b>Pruebas:</b> {total} casos JUnit 5 ({lin_test} líneas)", sub),
          PageBreak()]

    # ------------------------------------------------ 1. resumen
    s += [P("1. Resumen", h1),
          P("Se desarrolló una herramienta en Java 17 que modela la red de colaboradores de una consultora como un "
            "<b>grafo dirigido con pesos unitarios</b> (la arista <i>A → B</i> significa «A reporta a B») y responde las "
            "cuatro preguntas del caso: (1) qué comunidades aisladas existen, (2) si hay ciclos que invaliden la jerarquía, "
            "(3) cuál es el grado de influencia de cada persona y el camino simple más largo entre dos nodos, y (4) qué "
            "colaboradores son «puente» (puntos de articulación). Todo se implementó con la biblioteca estándar "
            "(<font name='DVM'>HashMap</font>, <font name='DVM'>HashSet</font>, <font name='DVM'>ArrayDeque</font>), incluido el "
            "analizador JSON."),
          P("Los algoritmos de conectividad, ciclos, grados y articulación son lineales, <b>O(V + E)</b>, y están "
            "implementados de forma iterativa para no desbordar la pila en redes muy profundas (se prueba una cadena de "
            "100 000 nodos). El camino simple más largo es <b>NP-difícil</b>; se resuelve con backtracking y una poda cuya "
            "cota se demuestra segura en la sección 5.4 y se valida empíricamente contra una búsqueda exhaustiva en "
            "miles de grafos aleatorios."),
          P(f"El conjunto de {total} pruebas incluye los seis escenarios exigidos (ciclo, árbol, dos componentes, un nodo, red vacía y "
            "auto-lazo) y comparaciones contra oráculos independientes. Además se aplicó <i>prueba de mutación</i> manual: "
            "los 7 defectos inyectados en los algoritmos fueron detectados por la suite."),
          sp(2)]

    s += [P("Trazabilidad requerimiento → implementación → verificación", h3)]
    s += [tabla([
        ["Req.", "Descripción", "Clase", "Verificación"],
        ["RF1", "Carga de <font name='DVM'>red.json</font> / <font name='DVM'>red.csv</font> sin librerías", "CargadorRed, JsonMinimo", "CargadorRedTest"],
        ["RF2", "DFS/BFS: componentes y ciclos (dirigido y no dirigido)", "Componentes, Ciclos", "ComponentesYCiclosTest"],
        ["RF3", "Grados de entrada/salida con lista de adyacencia", "Grados", "GradosCaminoArticulacionTest"],
        ["RF4", "Camino simple más largo, backtracking con poda; NP", "CaminoMasLargo", "GradosCaminoArticulacionTest"],
        ["RF5", "Puntos de articulación (Tarjan)", "PuntosArticulacion", "GradosCaminoArticulacionTest"],
        ["RF6", "Salida tabulada + <font name='DVM'>resultados.txt</font>", "Reporte, Main", "CasosBordeTest"],
    ], [1.1 * cm, 7.0 * cm, 4.2 * cm, W - 12.3 * cm])]

    # ------------------------------------------------ 2. modelado
    s += [P("2. Modelado del grafo", h1), P("2.1 Decisión: un solo grafo dirigido y una vista no dirigida derivada", h2),
          P("El enunciado pide un grafo dirigido y uno no dirigido derivado, y deja al estudiante decidir cómo mantener ambos "
            "o justificar uno solo. Los algoritmos necesitan <b>ambas</b> perspectivas: los grados y los ciclos de dependencia "
            "exigen el sentido de las aristas, mientras que las comunidades aisladas y los puntos de articulación son "
            "conceptos de conectividad que ignoran el sentido. Se evaluaron tres alternativas:")]
    s += [tabla([
        ["Alternativa", "Ventajas", "Desventajas", "Decisión"],
        ["A. Solo dirigido; recorrer en ambos sentidos con sucesores ∪ predecesores calculados en cada visita",
         "Una única fuente de verdad", "Cada visita crea la unión: sobrecosto constante en cada paso de BFS/DFS", "Descartada"],
        ["B. Dos grafos independientes (dirigido y no dirigido) que el cliente mantiene en paralelo",
         "Acceso directo a ambos", "Duplica memoria y obliga a sincronizar: riesgo de inconsistencia", "Descartada"],
        ["<b>C. Un grafo dirigido (mapas de sucesores y predecesores) + vista no dirigida derivada y cacheada</b>",
         "Fuente única; grados en O(1); vista construida una vez en O(V+E) y reutilizada; se invalida automáticamente al modificar",
         "Memoria extra O(V+E) para la caché", "<b>Elegida</b>"],
    ], [5.4 * cm, 4.6 * cm, 4.4 * cm, W - 14.4 * cm])]
    s += [sp(4), P("2.2 Estructuras de datos", h2),
          C("""
Grafo
 ├─ Map<String, Set<String>> sucesores      v → {w : v→w}      (a quién reporta v)
 ├─ Map<String, Set<String>> predecesores   v → {u : u→v}      (quién reporta a v)
 └─ Map<String, Set<String>> vistaNoDirigida   (caché, derivada)  v → sucesores ∪ predecesores − {v}

Ejemplo:  B→A, C→A, D→B, A→A
  sucesores     = { A:{A}, B:{A}, C:{A}, D:{B} }
  predecesores  = { A:{B,C,A}, B:{D}, C:{}, D:{} }
  vistaNoDirig. = { A:{B,C}, B:{A,D}, C:{A}, D:{B} }       (el auto-lazo A→A se descarta)
""")]
    s += [P("Se usan <font name='DVM'>LinkedHashMap</font> y <font name='DVM'>LinkedHashSet</font>, que son subclases de "
            "<font name='DVM'>HashMap</font>/<font name='DVM'>HashSet</font> con idénticas complejidades esperadas "
            "(O(1) para insertar, consultar y borrar) y que además conservan el orden de inserción; así la salida es "
            "determinista y reproducible entre ejecuciones. Una <b>matriz de adyacencia</b> se descartó por requerir O(V²) "
            "de memoria en una red de colaboradores que es dispersa (|E| ≈ |V|), y un <font name='DVM'>TreeMap</font> por "
            "degradar los accesos a O(log V) sin ganar nada."),
          P("<b>Complejidad espacial:</b> O(V + E) (tres mapas). <b>Costos:</b> agregar nodo/arista O(1) esperado; "
            "sucesores/predecesores O(1); vecinos O(1) tras la primera construcción de la vista, O(V+E) una sola vez "
            "después de cada modificación.")]
    s += [P("2.3 Convenciones sobre casos especiales", h2),
          tabla([
              ["Situación", "Vista dirigida", "Vista no dirigida"],
              ["Auto-lazo <i>A → A</i>", "Ciclo de longitud 1; suma 1 al grado de entrada y 1 al de salida",
               "Se descarta de las listas de vecinos (no afecta conectividad ni articulación), pero se reporta como ciclo de longitud 1"],
              ["Arista mutua <i>A → B</i> y <i>B → A</i>", "Ciclo de longitud 2 (jerarquía inválida)",
               "Una sola arista {A,B}: <b>no</b> es ciclo"],
              ["Arista repetida", "Se ignora (grafo simple dirigido)", "—"],
              ["Arista con nodo no declarado", "El nodo se crea automáticamente", "—"],
              ["Identificador nulo o en blanco", "<font name='DVM'>IllegalArgumentException</font>", "—"],
          ], [4.0 * cm, 5.7 * cm, W - 9.7 * cm])]

    # ------------------------------------------------ 3. formato
    s += [P("3. Formato de datos y carga (RF1)", h1),
          P("Se aceptan los dos formatos del enunciado, eligiendo el parser por la extensión. <b>JSON es el formato principal</b>; "
            "CSV se mantiene como alternativa sencilla:"),
          tabla([
              ["Criterio", "JSON (principal)", "CSV"],
              ["Nodos aislados (necesarios para «red de 1 nodo» y «2 componentes»)",
               "Natural: lista <font name='DVM'>\"nodos\"</font> separada de <font name='DVM'>\"aristas\"</font>",
               "Requiere convención: fila con un solo valor (<font name='DVM'>Paula,</font>)"],
              ["Autodescriptivo y extensible (rol, área…)", "Sí: se añaden claves sin romper el parser", "No: columnas posicionales"],
              ["Validación de esquema y mensajes de error", "Línea y columna exactas del error", "Número de línea"],
              ["Dificultad del parser sin librerías", "Media (descenso recursivo, ≈200 líneas)", "Baja (≈40 líneas)"],
              ["Edición desde hoja de cálculo", "Incómoda", "Directa"],
          ], [5.6 * cm, 5.9 * cm, W - 11.5 * cm]),
          sp(4),
          P("<b>Parser JSON propio.</b> <font name='DVM'>JsonMinimo</font> implementa la gramática de RFC 8259 con descenso recursivo: "
            "<font name='DVM'>valor → objeto | arreglo | cadena | número | true | false | null</font>. Maneja escapes "
            "(<font name='DVM'>\\n \\t \\\" \\\\ \\uXXXX</font>), rechaza caracteres de control sin escapar, contenido sobrante y "
            "estructuras truncadas, e informa línea y columna. Es O(n) en el tamaño del texto. <font name='DVM'>CargadorRed</font> "
            "valida después el esquema (<font name='DVM'>nodos</font>: arreglo de cadenas; <font name='DVM'>aristas</font>: objetos con "
            "<font name='DVM'>origen</font> y <font name='DVM'>destino</font> como cadenas). Se tolera el BOM UTF-8 y se lee siempre en UTF-8."),
          P("<b>CSV.</b> Se admiten encabezado opcional <font name='DVM'>origen,destino</font>, comentarios con "
            "<font name='DVM'>#</font>, líneas en blanco, campos entre comillas con comas y <font name='DVM'>\"\"</font> como comilla literal."),
          C("""
{ "nodos":   ["Ana", "Beto", "Paula"],            origen,destino
  "aristas": [ {"origen":"Beto","destino":"Ana"} ] }     Beto,Ana
                                                          Paula,
""")]

    # ------------------------------------------------ 4/5. algoritmos
    s += [P("4. Estructuras auxiliares: por qué ArrayDeque y no Stack ni LinkedList", h1),
          P("BFS necesita una cola y el DFS iterativo una pila. Se usa <font name='DVM'>ArrayDeque</font> en ambos casos "
            "(<font name='DVM'>add/poll</font> como cola; <font name='DVM'>push/pop/peek</font> como pila):"),
          tabla([
              ["Aspecto", "Stack", "LinkedList", "ArrayDeque"],
              ["Implementación", "Extiende <font name='DVM'>Vector</font> (clase heredada)", "Lista doblemente enlazada", "Arreglo circular redimensionable"],
              ["Sincronización", "Todos los métodos <font name='DVM'>synchronized</font>: costo inútil en un solo hilo", "No", "No"],
              ["Memoria por elemento", "Una referencia", "Un objeto <font name='DVM'>Node</font> adicional (≈24 B con punteros comprimidos)", "Una referencia"],
              ["Localidad de caché", "Buena", "Mala: nodos dispersos en el heap, más trabajo para el recolector", "Buena"],
              ["Push/pop o add/poll en extremos", "O(1) amortizado", "O(1)", "O(1) amortizado"],
              ["Abstracción expuesta", "Como es un <font name='DVM'>Vector</font> permite <font name='DVM'>get(i)</font> e inserciones intermedias: rompe LIFO",
               "Implementa <font name='DVM'>List</font> y <font name='DVM'>Deque</font>: API demasiado amplia", "Solo <font name='DVM'>Deque</font>: justo lo que se necesita"],
              ["Elementos <font name='DVM'>null</font>", "Permite", "Permite (puede ocultar errores)", "Los prohíbe: falla rápido"],
              ["Guía oficial (Javadoc)", "Recomienda preferir <font name='DVM'>Deque</font> a esta clase", "—", "Indica que probablemente es más rápida que <font name='DVM'>Stack</font> como pila y que <font name='DVM'>LinkedList</font> como cola"],
          ], [3.4 * cm, 4.6 * cm, 4.6 * cm, W - 12.6 * cm]),
          sp(3),
          P("<font name='DVM'>HashSet</font> se usa para conjuntos de visitados (pertenencia y alta en O(1) esperado; "
            "<font name='DVM'>add</font> devuelve <i>false</i> si ya estaba, lo que permite «marcar y comprobar» en una sola operación) "
            "y <font name='DVM'>HashMap</font> para <i>color</i>, <i>padre</i>, <i>disc</i> y <i>low</i>.")]

    s += [P("5. Algoritmos, corrección y complejidad", h1), P("5.1 Componentes conexas – BFS (RF2)", h2),
          P("Se ejecuta sobre la vista no dirigida: son componentes <i>débilmente</i> conexas, que es lo apropiado para "
            "«comunidades aisladas». Cada nodo se encola exactamente una vez."),
          C("""
COMPONENTES(G):
  visitados ← ∅ ; resultado ← []
  para cada v ∈ V:
    si v ∉ visitados:
      C ← ∅ ; cola ← [v] ; visitados ← visitados ∪ {v}
      mientras cola ≠ ∅:
        x ← desencolar() ; C ← C ∪ {x}
        para cada w ∈ vecinos(x):
          si w ∉ visitados: visitados ← visitados ∪ {w} ; encolar(w)
      resultado.agregar(C)
  devolver resultado ordenado por tamaño descendente
"""),
          P("<b>Corrección:</b> BFS desde <i>v</i> visita exactamente los nodos alcanzables desde <i>v</i>; al iniciar un nuevo BFS solo "
            "desde nodos aún no visitados, las componentes son disjuntas y cubren V (verificado en pruebas aleatorias: "
            "Σ|C<sub>i</sub>| = |V|). <b>Complejidad:</b> O(V + E) tiempo, O(V) espacio.")]

    s += [P("5.2 Detección de ciclos – DFS iterativo (RF2)", h2),
          P("<b>Dirigido (coloreo en tres estados).</b> <i>Blanco</i> = no visitado; <i>gris</i> = en la pila del DFS actual (es "
            "ancestro del nodo que se explora); <i>negro</i> = terminado. Hay un ciclo dirigido si y solo si el DFS encuentra "
            "una arista hacia un nodo gris (arista de retroceso; Cormen et al., capítulo «Elementary Graph Algorithms»). Con ella se reconstruye el "
            "ciclo siguiendo los padres desde el nodo actual hasta el nodo gris alcanzado."),
          C("""
CICLO-DIRIGIDO(G):
  para cada raíz r con color[r] = BLANCO:
    pila ← [r] ; color[r] ← GRIS
    mientras pila ≠ ∅:
      v ← tope(pila)
      si v tiene un sucesor w sin examinar:
        si color[w] = BLANCO: padre[w] ← v ; color[w] ← GRIS ; apilar(w)
        sino si color[w] = GRIS: devolver reconstruir(w ~> v -> w)      // arista de retroceso
      sino: color[v] ← NEGRO ; desapilar()
  devolver ∅
"""),
          P("<b>No dirigido.</b> Sobre la vista derivada (grafo simple), hay ciclo si y solo si el DFS encuentra una arista a un nodo "
            "ya visitado que no sea el padre inmediato. Como el DFS termina al primer hallazgo, esa arista siempre apunta a un "
            "<i>ancestro</i>: si apuntara a un descendiente, éste ya la habría examinado antes desde su lado y habría terminado "
            "la búsqueda. Un auto-lazo se reporta como ciclo [A, A] antes de iniciar el recorrido."),
          P("Observación importante para el modelado: <i>A → B</i> junto con <i>B → A</i> es un ciclo dirigido (dos personas que se reportan "
            "mutuamente), pero se colapsa en una sola arista no dirigida y por eso <b>no</b> es ciclo no dirigido; se cubre con pruebas. "
            "<b>Complejidad:</b> O(V + E) tiempo, O(V) espacio. La pila explícita evita <font name='DVM'>StackOverflowError</font>: "
            "una cadena de 100 000 nodos se procesa sin problema (prueba automatizada).")]

    s += [P("5.3 Grados de entrada y salida (RF3)", h2),
          P("El <b>grado de salida</b> de <i>v</i> es el tamaño de su lista de adyacencia (a cuántas personas reporta). El <b>grado de entrada</b> "
            "se obtiene en una sola pasada sobre todas las listas, incrementando un contador por cada destino (cuántas personas le reportan). "
            "La <b>influencia total</b> es entrada + salida; el ranking ordena por total, luego por entrada, luego alfabéticamente. "
            "Invariante verificado en pruebas: Σ entradas = Σ salidas = |E|, y coincide con el tamaño del mapa de predecesores. "
            "<b>Complejidad:</b> O(V + E).")]

    s += [P("5.4 Camino simple más largo (RF4)", h2),
          P("<b>¿Por qué no hay algoritmo polinomial?</b> Dados <i>s</i> y <i>t</i>, un grafo de <i>n</i> nodos tiene un camino hamiltoniano de "
            "<i>s</i> a <i>t</i> si y solo si su camino simple más largo de <i>s</i> a <i>t</i> tiene exactamente <i>n − 1</i> aristas. Como el camino "
            "hamiltoniano con extremos dados es NP-completo (Garey y Johnson, 1979), la versión de decisión «¿existe un camino simple de "
            "<i>s</i> a <i>t</i> con al menos <i>k</i> aristas?» es NP-completa (pertenece a NP: el certificado es el camino, verificable en O(n)) y la "
            "versión de optimización es NP-difícil. A diferencia del camino más <i>corto</i>, no se conoce algoritmo polinomial salvo que P = NP."),
          P("<b>Algoritmo.</b> Backtracking (DFS exhaustivo con retroceso): se extiende el camino actual con vecinos no visitados y se deshace "
            "al volver. Un camino simple termina al llegar a <i>t</i>. Se mantiene la mejor longitud <i>L*</i>."),
          C("""
RETROCEDER(v):                                     // camino = [s, ..., v], enCamino = conjunto de sus nodos
  si v = t: si |camino|−1 > L*: L* ← |camino|−1 ; mejor ← copia(camino)
            devolver
  L ← |camino| − 1
  si L + (n − |camino|) ≤ L*: devolver             // cota barata:  |R| ≤ nodos sin visitar
  R ← nodos no visitados alcanzables desde v por nodos no visitados      // BFS, O(V+E)
  si t ∉ R  o  L + |R| ≤ L*: devolver              // PODA
  para cada w ∈ ady(v) con w ∉ enCamino:
    camino.agregarFinal(w) ; enCamino ← enCamino ∪ {w}
    RETROCEDER(w)
    camino.quitarFinal() ; enCamino ← enCamino − {w}
"""),
          P("<b>Cota y su justificación.</b> Sea <i>L</i> la longitud del camino actual <i>P</i> que termina en <i>v</i> y sea <i>R</i> el conjunto de nodos "
            "no visitados alcanzables desde <i>v</i> usando solo nodos no visitados."),
          P("<b>Lema.</b> Toda extensión simple <i>Q</i> de <i>P</i> hasta <i>t</i> tiene a lo sumo <i>L + |R|</i> aristas, y si <i>t ∉ R</i> no existe ninguna."),
          P("<i>Demostración.</i> Los nodos que <i>Q</i> añade después de <i>v</i> son distintos entre sí y distintos de los de <i>P</i> (la extensión es "
            "simple). Cada uno es alcanzable desde <i>v</i> por el trozo inicial de <i>Q</i>, que solo pasa por nodos añadidos, es decir, no visitados; "
            "luego pertenecen a <i>R</i>. Como cada arista nueva entra a un nodo nuevo distinto, <i>Q</i> añade a lo sumo |R| aristas. Si <i>t ∉ R</i>, "
            "ningún <i>Q</i> puede llegar a <i>t</i>. ∎"),
          P("Por tanto las dos podas son <b>seguras</b>: si <i>L + |R| ≤ L*</i>, ninguna extensión puede <i>superar</i> la mejor solución conocida, y si "
            "<i>t ∉ R</i> la rama es infructuosa. Nunca se descarta una solución estrictamente mejor. Esto se verificó empíricamente: en 400 grafos "
            "aleatorios y en ambos modos (dirigido y no dirigido) la longitud devuelta coincide con la de una búsqueda exhaustiva "
            "<i>sin poda</i> implementada de forma independiente en las pruebas; y un «mutante» con la cota sobre-ajustada fue detectado."),
          P("<b>Complejidad.</b> En el peor caso el árbol de búsqueda recorre todos los caminos simples desde <i>s</i>. En el grafo completo K<sub>n</sub> "
            "hay Σ<sub>k=0</sub><super>n−2</super> (n−2)!/(n−2−k)! ≈ e·(n−2)! caminos simples de <i>s</i> a <i>t</i>, y cada nodo expandido cuesta O(V+E) por el BFS "
            "de la poda: <b>O(n!·(V+E)) en el peor caso, espacio O(V)</b>. La poda no mejora este peor caso (no puede: el problema es NP-difícil); lo que "
            "hace es reducir drásticamente el trabajo en la práctica (sección 9). Casos polinomiales: en un <b>DAG</b> dirigido se resuelve en "
            "<b>O(V+E)</b> por programación dinámica (<font name='DVM'>longitudEnDag</font>, que además sirve como oráculo de pruebas) y en un "
            "<b>árbol</b> el camino simple es único."),
          P("<b>Limitaciones asumidas:</b> si hay varios caminos de longitud máxima se devuelve uno (el primero hallado, determinista); la recursión "
            "tiene profundidad ≤ |V|; y no hay límite de tiempo, por lo que para redes densas de decenas de nodos la consulta puede tardar "
            "(ver sección 10).")]

    s += [P("5.5 Puntos de articulación – Tarjan (RF5)", h2),
          P("Un punto de articulación es un nodo cuya eliminación aumenta el número de componentes: un «colaborador puente». Se aplica el "
            "algoritmo de Tarjan / Hopcroft–Tarjan sobre la vista no dirigida. Para cada nodo se guarda <i>disc[v]</i> (orden de descubrimiento) y "
            "<i>low[v]</i> (el menor <i>disc</i> alcanzable desde el subárbol de <i>v</i> usando a lo sumo una arista de retroceso)."),
          C("""
ARTICULACIONES(G):                       t ← 0 ; A ← ∅
  para cada raíz r no visitada:
    disc[r] ← low[r] ← ++t ; hijos ← 0
    // DFS iterativo (pila ArrayDeque). Para cada arista v–w examinada:
    //   w no visitado  : padre[w] ← v ; disc[w] ← low[w] ← ++t ; si v = r: hijos++ ; apilar(w)
    //   w visitado, w ≠ padre[v] (retroceso): low[v] ← min(low[v], disc[w])
    // Al terminar v con padre p:
    //   low[p] ← min(low[p], low[v])
    //   si p ≠ r  y  low[v] ≥ disc[p]:  A ← A ∪ {p}
    si hijos > 1: A ← A ∪ {r}
  devolver A
"""),
          P("<b>Corrección (idea).</b> Si <i>p</i> no es raíz y un hijo <i>v</i> cumple <i>low[v] ≥ disc[p]</i>, el subárbol de <i>v</i> no tiene ninguna arista "
            "de retroceso que salte por encima de <i>p</i>; al quitar <i>p</i> ese subárbol queda aislado del resto. Recíprocamente, si todo hijo "
            "tiene <i>low[v] &lt; disc[p]</i>, cada subárbol escapa por un ancestro de <i>p</i> y <i>p</i> no desconecta. La raíz es punto de "
            "articulación solo si tiene ≥ 2 hijos en el árbol DFS, pues entonces esos hijos solo se comunican a través de ella. Como la vista derivada es "
            "un grafo simple (sin aristas paralelas), omitir al padre <i>por nodo</i> es correcto."),
          P("Para medir el «impacto» de cada puente, <font name='DVM'>fragmentosAlEliminar(v)</font> hace un BFS desde cada vecino sin pasar por <i>v</i> "
            "y cuenta en cuántos pedazos se parte su componente (<i>v</i> es articulación ⇔ ≥ 2). Se usó también como <b>definición independiente</b> para validar "
            "a Tarjan sobre 500 grafos aleatorios. <b>Complejidad de Tarjan:</b> O(V + E) tiempo, O(V) espacio; los fragmentos, O(V+E) por nodo consultado.")]

    # ------------------------------------------------ 6. complejidad global
    s += [P("6. Resumen de complejidad", h1),
          tabla([
              ["Operación", "Tiempo", "Espacio extra", "Observación"],
              ["Construir grafo (cargar)", "O(V + E) esperado", "O(V + E)", "Parser JSON O(n) en el tamaño del texto"],
              ["Vista no dirigida (1.ª vez / tras modificar)", "O(V + E)", "O(V + E)", "Cacheada"],
              ["Componentes (BFS)", "O(V + E)", "O(V)", ""],
              ["Ciclo dirigido (DFS 3 colores)", "O(V + E)", "O(V)", "Iterativo"],
              ["Ciclo no dirigido (DFS con padre)", "O(V + E)", "O(V)", "Iterativo"],
              ["Grados de entrada/salida", "O(V + E)", "O(V)", ""],
              ["Puntos de articulación (Tarjan)", "O(V + E)", "O(V)", "Iterativo"],
              ["Camino simple más largo", "O(n!·(V+E)) peor caso", "O(V)", "NP-difícil; poda mejora la práctica, no el peor caso"],
              ["Camino más largo en DAG (DP)", "O(V + E)", "O(V)", "Caso polinomial"],
          ], [5.6 * cm, 3.8 * cm, 2.6 * cm, W - 12.0 * cm])]

    # ------------------------------------------------ 7. pruebas
    s += [P("7. Pruebas y casos borde", h1),
          P(f"La suite JUnit 5 contiene <b>{total} pruebas</b> repartidas en {len(pruebas)} clases. Ejecución: "
            "<font name='DVM'>mvn clean test</font>."),
          tabla([["Clase de prueba", "Casos", "Qué verifica"]] + [
              [n, str(pruebas[n]), d] for n, d in [
                  ("GrafoTest", "Consistencia entrada/salida, duplicados, vista derivada y su invalidación, auto-lazo, vistas de solo lectura, excepciones"),
                  ("CargadorRedTest", "JSON y CSV válidos e inválidos (≥13 entradas corruptas), escapes, Unicode, BOM, nodos aislados, mensaje con línea, equivalencia de <font name='DVM'>red.json</font> ≡ <font name='DVM'>red.csv</font>"),
                  ("ComponentesYCiclosTest", "Componentes (partición aleatoria), ciclos dirigidos vs. algoritmo de Kahn (500 grafos), no dirigidos vs. fórmula E > V−C (500 grafos), cadena de 100 000 nodos"),
                  ("GradosCaminoArticulacionTest", "Grados e invariantes, camino más largo vs. búsqueda exhaustiva (400 grafos × 2 modos) y vs. DP en DAG (300), Tarjan vs. definición por eliminación (500 grafos)"),
                  ("CasosBordeTest", "Los seis escenarios exigidos + reporte y exportación UTF-8"),
              ] if n in pruebas
          ], [4.6 * cm, 1.3 * cm, W - 5.9 * cm]),
          sp(5), P("Los seis escenarios exigidos (<font name='DVM'>CasosBordeTest</font>)", h3),
          tabla([
              ["Escenario", "Red de prueba", "Resultado esperado (verificado)"],
              ["Grafo con ciclo", "A→B, B→C, C→A, D→A", "1 componente; ciclo dirigido y no dirigido; puente: A (aísla a D); A: entrada 2, salida 1"],
              ["Grafo en árbol", "B→A, C→A, D→B, E→B", "1 componente de 5; sin ciclos; |E| = |V|−1; puentes: A y B"],
              ["Dos componentes", "A→B, B→C, D→E", "2 componentes (3 y 2); sin ciclos; puente: B"],
              ["Red de 1 nodo", "Solo", "1 componente; sin ciclos; grados 0/0; sin puentes; camino Solo→Solo de 0 aristas"],
              ["Red vacía", "(sin nodos)", "0 componentes; sin ciclos ni puentes; el reporte se genera sin error"],
              ["Auto-lazo", "A→A, A→B", "Ciclo [A, A] dirigido y no dirigido; A: entrada 1, salida 2; sin puentes"],
          ], [3.0 * cm, 3.7 * cm, W - 6.7 * cm]),
          sp(5), P("Oráculos independientes y prueba de mutación", h3),
          P("Para no «verificar el algoritmo con sí mismo», las pruebas aleatorias (semilla fija, reproducibles) contrastan cada algoritmo con un oráculo "
            "distinto: <b>Kahn</b> (ordenación topológica) para ciclos dirigidos; el hecho de que un grafo simple tiene ciclo ⇔ E &gt; V − C para los no dirigidos; "
            "<b>exhaustiva sin poda</b> y <b>DP en DAG</b> para el camino más largo; y la <b>definición por eliminación de nodo</b> para Tarjan."),
          P("Para medir la calidad de la suite se inyectaron manualmente 7 defectos («mutantes») y se comprobó que la suite falla en cada uno:"),
          tabla([
              ["Mutante inyectado", "Pruebas que fallan", "Detectado"],
              ["Tarjan: <font name='DVM'>low[v] ≥ disc[p]</font> cambiado por <font name='DVM'>&gt;</font>", "2", "Sí"],
              ["Tarjan: raíz es articulación con ≥ 1 hijo (en vez de ≥ 2)", "11", "Sí"],
              ["Poda sobre-ajustada (descarta ramas que sí podían mejorar)", "3", "Sí"],
              ["Poda más débil (sigue siendo correcta, pero expande más)", "1 (la de eficiencia)", "Sí"],
              ["Ciclo dirigido: detectar nodos negros en vez de grises", "14", "Sí"],
              ["Ciclo no dirigido: no excluir al padre inmediato", "6", "Sí"],
              ["Componentes: seguir solo sucesores en vez de vecinos", "4", "Sí"],
          ], [8.5 * cm, 3.6 * cm, W - 12.1 * cm])]

    # ------------------------------------------------ 8. resultados
    s += [P("8. Resultados con la red de ejemplo (16 nodos)", h1),
          P("<font name='DVM'>data/red.json</font> describe una consultora de 16 colaboradores y 15 relaciones; <font name='DVM'>resultados.txt</font> "
            "es la salida completa del programa (idéntica en consola). La red se diseñó para ejercitar todos los análisis: tres comunidades, un ciclo "
            "de dependencia, un bucle de relaciones y varios puentes."),
          Image(f_red, width=W, height=W * 5.6 / 10.2),
          P("<b>Figura 1.</b> Red de ejemplo. Naranja = punto de articulación; rojo = ciclo de dependencia; recuadros punteados = componentes conexas.", nota),
          sp(4),
          tabla([
              ["Pregunta", "Resultado obtenido", "Interpretación"],
              ["1. Comunidades aisladas", "3 componentes: 12 · 3 (Marta, Nora, Óscar) · 1 (Paula)",
               "Paula no tiene ninguna relación; el equipo de Marta está desconectado del resto"],
              ["2. Ciclos",
               "Dirigido: <b>Jorge → Karla → Luis → Jorge</b>. No dirigido: Ana → Beto → Elena → Carla → Ana",
               "Jorge, Karla y Luis se reportan circularmente: <b>jerarquía inválida</b>. El bucle no dirigido es solo redundancia legítima (Elena reporta a dos jefes)"],
              ["3a. Influencia", "<b>Carla</b>: entrada 3, salida 1, total 4 (la mayor). Le siguen Beto, Elena y Jorge (total 3)",
               "Carla concentra más relaciones directas: a ella reportan Elena, Fabián y Gloria"],
              ["3b. Camino más largo Hugo → Ana", "Dirigido: 3 aristas (Hugo→Diego→Beto→Ana). No dirigido: <b>5</b> (Hugo–Diego–Beto–Elena–Carla–Ana)",
               "Sin respetar el sentido se aprovecha el bucle Ana–Beto–Elena–Carla y el camino crece"],
              ["3b. Irene → Fabián", "Dirigido: sin camino. No dirigido: 5 aristas",
               "Ambos están en la misma comunidad pero no hay una cadena de reporte entre ellos"],
              ["3b. Paula → Ana", "Sin camino en ambos modos", "Están en componentes distintas"],
              ["4. Colaboradores puente", "Beto, Carla (3 fragmentos), Diego, Elena, Gloria, Jorge y Marta",
               "Carla es crítica: si sale, la red se parte en 3 (Fabián; Gloria-Jorge-Karla-Luis; Ana-Beto-Elena-…). Ana <i>no</i> es puente porque el bucle la protege"],
          ], [3.3 * cm, 6.2 * cm, W - 9.5 * cm])]

    # ------------------------------------------------ 9. eficiencia
    s += [P("9. Evaluación de eficiencia", h1),
          P("Se midió el número de <b>nodos expandidos</b> por el backtracking con y sin poda (medida independiente de la máquina y del calentamiento de la JVM; los "
            "milisegundos de casos pequeños están dominados por el JIT y no son comparables). Camino entre dos nodos fijos, vista no dirigida:"),
          Image(f_poda, width=W * 0.82, height=W * 0.82 * 3.3 / 7.2),
          P("<b>Figura 2.</b> Expansiones en grafos completos: sin poda crecen ≈ n veces por cada nodo añadido (factorial); con poda crecen linealmente.", nota),
          tabla([
              ["Grafo (n, aristas)", "Longitud óptima", "Exhaustiva (llamadas)", "Con poda (expansiones)", "Factor"],
              ["K6 (6, 15)", "5", "130", "16", "8×"],
              ["K8 (8, 28)", "7", "3 914", "29", "135×"],
              ["K10 (10, 45)", "9", "219 202", "46", "≈ 4 800×"],
              ["K11 (11, 55)", "10", "1 972 820", "56", "≈ 35 000×"],
              ["Rejilla 3×3 (9, 12)", "8", "51", "13", "3.9×"],
              ["Rejilla 4×4 (16, 24)", "14", "1 271", "545", "2.3×"],
              ["Red de ejemplo, Hugo→Ana (16, 15)", "5", "—", "10", "—"],
          ], [5.4 * cm, 2.6 * cm, 3.2 * cm, 3.4 * cm, W - 14.6 * cm]),
          sp(4),
          P("<b>Lectura honesta de los datos.</b> En K<sub>n</sub> la poda es espectacular porque el primer camino encontrado ya es hamiltoniano (n−1 aristas, "
            "el máximo posible), y desde ese momento <i>L + |R| ≤ L*</i> descarta todo lo demás. En las rejillas, donde existen muchos caminos casi óptimos, la mejora es "
            "modesta (2–4×). Con grafos aleatorios dispersos de grado medio ≈ 3 y 10–18 nodos, el backtracking terminó con entre 35 y 944 expansiones. Es decir: "
            "la poda ayuda mucho, pero <b>no cambia la naturaleza exponencial</b> del problema; para redes densas grandes habría que acotar el tiempo o resolver el problema sobre una "
            "subred relevante. Cada expansión cuesta además un BFS de O(V+E), por lo que en grafos muy pequeños la poda puede costar más de lo que ahorra."),
          P("<b>Algoritmos lineales.</b> En una medición informal (una sola corrida, sin calentamiento) sobre un grafo aleatorio con 200 000 nodos y ≈400 000 aristas, "
            "componentes (incluida la construcción de la vista no dirigida), detección de ciclos, grados y puntos de articulación terminaron en pocos segundos; "
            "la programación dinámica en un DAG de 200 001 nodos tardó ≈1.5 s con la pila por defecto, al ser iterativa. Son cifras orientativas, no un banco de pruebas riguroso, pero son consistentes "
            "con el comportamiento O(V + E).")]

    # ------------------------------------------------ 10. limitaciones
    s += [P("10. Limitaciones y trabajo futuro", h1),
          tabla([
              ["Limitación", "Mejora posible"],
              ["Solo se reporta <i>un</i> ciclo de dependencia, no todos los nodos implicados", "Componentes fuertemente conexas (Tarjan/Kosaraju) para listar cada grupo circular"],
              ["El camino más largo no tiene límite de tiempo", "Parámetro de tiempo máximo / expansiones máximas con devolución de la mejor solución parcial; búsqueda por ramas con heurísticas de orden"],
              ["La recursión del backtracking tiene profundidad ≤ |V|", "Versión iterativa con pila explícita"],
              ["Pesos unitarios", "Generalizar con pesos enteros y adaptar la cota a la suma de pesos máximos"],
              ["Si hay empates entre caminos óptimos se devuelve solo uno", "Enumerar todos los óptimos"],
              ["Los argumentos con acentos dependen del locale de la JVM", "Documentado en el README (UTF-8)"],
          ], [7.4 * cm, W - 7.4 * cm])]

    # ------------------------------------------------ 11. originalidad / referencias
    s += [P("11. Originalidad y referencias", h1),
          P("Todo el código fuente del repositorio fue escrito para este examen usando únicamente <font name='DVM'>java.util</font> (JUnit 5 solo en el alcance "
            "de pruebas). <b>No se incorporó código de terceros.</b> Los algoritmos se implementaron a partir de las descripciones de la literatura citada:"),
          P("[1] T. H. Cormen, C. E. Leiserson, R. L. Rivest, C. Stein. <i>Introduction to Algorithms</i>, 4.ª ed. MIT Press, 2022. (BFS, DFS, clasificación de aristas, ciclos.)<br/>"
            "[2] R. E. Tarjan. «Depth-first search and linear graph algorithms». <i>SIAM Journal on Computing</i> 1(2):146–160, 1972.<br/>"
            "[3] J. Hopcroft, R. Tarjan. «Algorithm 447: Efficient algorithms for graph manipulation». <i>Communications of the ACM</i> 16(6):372–378, 1973. (Puntos de articulación.)<br/>"
            "[4] M. R. Garey, D. S. Johnson. <i>Computers and Intractability: A Guide to the Theory of NP-Completeness</i>. W. H. Freeman, 1979. (Problema del camino hamiltoniano.)<br/>"
            "[5] A. B. Kahn. «Topological sorting of large networks». <i>Communications of the ACM</i> 5(11):558–562, 1962. (Oráculo de las pruebas de ciclos.)<br/>"
            "[6] Oracle. <i>Java SE 17 API Specification</i>: <font name='DVM'>java.util.ArrayDeque</font>, <font name='DVM'>java.util.Stack</font>, <font name='DVM'>java.util.LinkedList</font>, <font name='DVM'>java.util.LinkedHashMap</font>.<br/>"
            "[7] T. Bray (ed.). <i>RFC 8259: The JavaScript Object Notation (JSON) Data Interchange Format</i>. IETF, 2017.", base)]
    return s


def main():
    doc = BaseDocTemplate(SALIDA, pagesize=letter, leftMargin=2.2 * cm, rightMargin=2.2 * cm,
                          topMargin=2.0 * cm, bottomMargin=2.2 * cm,
                          title="Análisis de redes de colaboradores – Reporte técnico",
                          author="Examen práctico – Estructuras de Datos y Algoritmia")
    marco = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="n")
    doc.addPageTemplates([PageTemplate(id="p", frames=[marco], onPage=pie)])
    doc.build(construir())
    print("Generado:", SALIDA)


if __name__ == "__main__":
    main()
