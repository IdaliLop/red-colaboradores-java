package consultora.red;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Set;
import java.util.function.Function;

/**
 * Camino <b>simple</b> (sin repetir nodos) más largo, medido en número de aristas, entre dos
 * nodos dados (RF4).
 *
 * <h2>Complejidad del problema</h2>
 * <p>El problema es <b>NP-difícil</b> en grafos generales. Decidir si existe un camino simple
 * de {@code s} a {@code t} con al menos {@code k} aristas es NP-completo: con {@code k = n−1}
 * es exactamente el problema del camino hamiltoniano entre {@code s} y {@code t} (Garey &amp;
 * Johnson, 1979). Por lo tanto no se conoce un algoritmo polinomial; el backtracking tiene
 * peor caso exponencial: el número de caminos simples puede llegar a Θ(n!) (grafo completo)
 * y cada nodo expandido cuesta O(V+E) por la poda, es decir, O(n!·(V+E)) en el peor caso.</p>
 *
 * <h2>Algoritmo</h2>
 * <p>Backtracking (DFS exhaustivo) que extiende el camino actual con vecinos no visitados,
 * y retrocede al terminar. Un camino simple termina al llegar a {@code t} (continuar
 * obligaría a revisitarlo).</p>
 *
 * <h2>Cota de poda (y su justificación)</h2>
 * <p>Sea {@code L} la longitud (aristas) del camino actual que termina en {@code v}, y sea
 * {@code R} el conjunto de nodos <em>no visitados</em> alcanzables desde {@code v} usando
 * solo nodos no visitados. Cualquier prolongación simple de {@code v} hasta {@code t} usa
 * únicamente nodos de {@code R} y cada arista nueva entra a un nodo distinto, luego añade
 * <b>a lo sumo |R|</b> aristas. Por tanto:</p>
 * <ol>
 *   <li>si {@code t ∉ R}, ninguna prolongación llega a {@code t} → se poda;</li>
 *   <li>si {@code L + |R| ≤ mejor}, ninguna prolongación puede <em>superar</em> la mejor
 *       solución conocida → se poda.</li>
 * </ol>
 * <p>Ambas podas son seguras (nunca descartan una solución estrictamente mejor), lo que se
 * verifica en las pruebas contra una búsqueda exhaustiva sin poda. {@code |R| ≤ n − |camino|}
 * es una cota aún más barata que se evalúa primero. En los mejores casos (árboles, DAG
 * pequeños, grafos casi lineales) la poda reduce la búsqueda a un número casi lineal de
 * expansiones, pero <b>no mejora el peor caso</b>.</p>
 *
 * <h2>Casos polinomiales</h2>
 * <p>En un DAG dirigido el problema se resuelve en O(V+E) por programación dinámica
 * ({@link #longitudEnDag}); en un árbol el camino simple es único.</p>
 *
 * <p>Limitación: la recursión tiene profundidad ≤ |V|; es adecuada para las redes de tamaño
 * moderado en las que una búsqueda exponencial es siquiera viable.</p>
 */
public final class CaminoMasLargo {

    /**
     * Resultado de la búsqueda.
     *
     * @param camino     nodos del camino, de origen a destino
     * @param expansiones nodos expandidos por el backtracking (medida de esfuerzo)
     */
    public record Resultado(List<String> camino, long expansiones) {
        /** @return longitud del camino en número de aristas */
        public int aristas() {
            return camino.size() - 1;
        }
    }

    private final Grafo g;
    private final String destino;
    private final Function<String, Collection<String>> adyacentes;
    private final Set<String> enCamino = new HashSet<>();
    private final Deque<String> camino = new ArrayDeque<>();
    private List<String> mejor;
    private int mejorLongitud = -1;
    private long expansiones;

    private CaminoMasLargo(Grafo g, String destino, boolean dirigido) {
        this.g = g;
        this.destino = destino;
        this.adyacentes = dirigido ? g::sucesores : g::vecinos;
    }

    /**
     * Busca un camino simple de longitud máxima entre dos nodos.
     *
     * <p>Si hay varios caminos de longitud máxima se devuelve uno de ellos (el primero que
     * encuentre el recorrido, que es determinista).</p>
     *
     * @param g       grafo
     * @param origen  nodo inicial
     * @param destino nodo final
     * @param dirigido {@code true} para respetar el sentido de las aristas;
     *                 {@code false} para usar la vista no dirigida
     * @return el camino y estadísticas, o vacío si {@code destino} no es alcanzable
     * @throws IllegalArgumentException si alguno de los nodos no existe
     */
    public static Optional<Resultado> buscar(Grafo g, String origen, String destino, boolean dirigido) {
        if (!g.contieneNodo(origen)) {
            throw new IllegalArgumentException("El nodo origen no existe en la red: " + origen);
        }
        if (!g.contieneNodo(destino)) {
            throw new IllegalArgumentException("El nodo destino no existe en la red: " + destino);
        }
        CaminoMasLargo b = new CaminoMasLargo(g, destino, dirigido);
        b.enCamino.add(origen);
        b.camino.addLast(origen);
        b.retroceder(origen);
        return b.mejor == null ? Optional.empty() : Optional.of(new Resultado(b.mejor, b.expansiones));
    }

    private void retroceder(String v) {
        expansiones++;
        if (v.equals(destino)) {
            int longitud = camino.size() - 1;
            if (longitud > mejorLongitud) {
                mejorLongitud = longitud;
                mejor = new ArrayList<>(camino);
            }
            return; // un camino simple termina al llegar al destino
        }
        int longitudActual = camino.size() - 1;
        // Cota barata: a lo sumo quedan (n - |camino|) nodos por visitar.
        if (longitudActual + (g.numNodos() - camino.size()) <= mejorLongitud) {
            return;
        }
        // Cota fina: |R| y alcanzabilidad del destino.
        int alcanzables = contarAlcanzables(v);
        if (alcanzables < 0 || longitudActual + alcanzables <= mejorLongitud) {
            return;
        }
        for (String w : adyacentes.apply(v)) {
            if (enCamino.add(w)) {
                camino.addLast(w);
                retroceder(w);
                camino.removeLast();
                enCamino.remove(w);
            }
        }
    }

    /**
     * BFS desde {@code v} por nodos no visitados.
     *
     * @return |R| (sin contar {@code v}), o -1 si el destino no pertenece a R
     */
    private int contarAlcanzables(String v) {
        Set<String> vistos = new HashSet<>();
        Deque<String> cola = new ArrayDeque<>();
        vistos.add(v);
        cola.add(v);
        boolean veDestino = false;
        while (!cola.isEmpty()) {
            String x = cola.poll();
            for (String w : adyacentes.apply(x)) {
                if (!enCamino.contains(w) && vistos.add(w)) {
                    if (w.equals(destino)) {
                        veDestino = true;
                    }
                    cola.add(w);
                }
            }
        }
        return veDestino ? vistos.size() - 1 : -1;
    }

    /**
     * Longitud del camino más largo entre dos nodos en un <b>DAG</b> en tiempo O(V+E),
     * mediante programación dinámica sobre el orden topológico (algoritmo de Kahn), sin
     * recursión. Se ofrece como caso polinomial y como oráculo independiente para validar
     * el backtracking.
     *
     * @param g       grafo que debe ser acíclico en sentido dirigido
     * @param origen  nodo inicial
     * @param destino nodo final
     * @return longitud en aristas, o vacío si no hay camino dirigido
     * @throws IllegalStateException    si el grafo contiene un ciclo dirigido
     * @throws IllegalArgumentException si algún nodo no existe
     */
    public static OptionalInt longitudEnDag(Grafo g, String origen, String destino) {
        if (!g.contieneNodo(origen) || !g.contieneNodo(destino)) {
            throw new IllegalArgumentException("Origen o destino inexistente en la red");
        }
        if (Ciclos.cicloDirigido(g).isPresent()) {
            throw new IllegalStateException("El grafo tiene ciclos: no es un DAG");
        }
        // Orden topológico (Kahn): se procesa un nodo cuando ya se procesaron todos sus predecesores.
        Map<String, Integer> pendientes = new HashMap<>();
        Deque<String> cola = new ArrayDeque<>();
        for (String v : g.nodos()) {
            int d = g.predecesores(v).size();
            pendientes.put(v, d);
            if (d == 0) {
                cola.add(v);
            }
        }
        List<String> orden = new ArrayList<>(g.numNodos());
        while (!cola.isEmpty()) {
            String v = cola.poll();
            orden.add(v);
            for (String w : g.sucesores(v)) {
                if (pendientes.merge(w, -1, Integer::sum) == 0) {
                    cola.add(w);
                }
            }
        }
        // PD en orden topológico inverso: mejor[v] = aristas del camino más largo v ~> destino (-1 si no hay).
        Map<String, Integer> mejor = new HashMap<>();
        for (int i = orden.size() - 1; i >= 0; i--) {
            String v = orden.get(i);
            int m = -1;
            if (v.equals(destino)) {
                m = 0;
            } else {
                for (String w : g.sucesores(v)) {
                    int r = mejor.get(w);
                    if (r >= 0) {
                        m = Math.max(m, r + 1);
                    }
                }
            }
            mejor.put(v, m);
        }
        int r = mejor.get(origen);
        return r < 0 ? OptionalInt.empty() : OptionalInt.of(r);
    }
}
