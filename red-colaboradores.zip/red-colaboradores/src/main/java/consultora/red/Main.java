package consultora.red;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Punto de entrada. Uso:
 *
 * <pre>
 * java -cp target/classes consultora.red.Main [archivo] [-o salida.txt] [--par ORIGEN DESTINO]...
 * </pre>
 *
 * <p>Valores por defecto: {@code data/red.json} y {@code resultados.txt}. La opción
 * {@code --par} puede repetirse para consultar varios caminos más largos.</p>
 */
public final class Main {

    private Main() {
    }

    /**
     * @param args argumentos de línea de comandos (ver descripción de la clase)
     */
    public static void main(String[] args) {
        PrintStream out = new PrintStream(System.out, true, StandardCharsets.UTF_8);
        try {
            String archivo = "data/red.json";
            String salida = "resultados.txt";
            List<Reporte.Par> pares = new ArrayList<>();

            for (int i = 0; i < args.length; i++) {
                switch (args[i]) {
                    case "-o":
                        salida = valor(args, ++i, "-o");
                        break;
                    case "--par":
                        String o = valor(args, ++i, "--par");
                        String d = valor(args, ++i, "--par");
                        pares.add(new Reporte.Par(o, d));
                        break;
                    default:
                        archivo = args[i];
                }
            }

            Grafo g = CargadorRed.cargar(Path.of(archivo));
            AnalisisRed analisis = AnalisisRed.analizar(g);
            String texto = Reporte.generar(archivo, analisis, pares);

            out.print(texto);
            Reporte.exportar(texto, Path.of(salida));
            out.println("Resultados exportados a: " + salida);
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Error de lectura/escritura (" + e.getClass().getSimpleName() + "): " + e.getMessage());
            System.exit(1);
        }
    }

    private static String valor(String[] args, int i, String opcion) {
        if (i >= args.length) {
            throw new IllegalArgumentException("Falta un argumento para " + opcion);
        }
        return args[i];
    }
}
