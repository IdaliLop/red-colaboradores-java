package consultora.red;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Analizador JSON de descenso recursivo escrito desde cero (RFC 8259), sin librerías.
 *
 * <p>Mapeo de tipos: objeto → {@code Map<String,Object>}, arreglo → {@code List<Object>},
 * cadena → {@code String}, número → {@code Double}, booleano → {@code Boolean},
 * {@code null} → {@code null}.</p>
 *
 * <p>Complejidad: O(n) en el tamaño del texto. Profundidad de recursión = profundidad de
 * anidamiento del documento (en este caso, 3 niveles).</p>
 */
final class JsonMinimo {

    private final String s;
    private int i;

    private JsonMinimo(String texto) {
        this.s = texto;
    }

    /**
     * Analiza un documento JSON completo.
     *
     * @param texto contenido JSON
     * @return objeto Java equivalente
     * @throws IllegalArgumentException si el texto no es JSON válido
     */
    static Object parsear(String texto) {
        JsonMinimo p = new JsonMinimo(texto);
        p.espacios();
        Object v = p.valor();
        p.espacios();
        if (p.i < p.s.length()) {
            throw p.error("Contenido inesperado después del documento");
        }
        return v;
    }

    private Object valor() {
        if (i >= s.length()) {
            throw error("Fin de entrada inesperado");
        }
        char c = s.charAt(i);
        switch (c) {
            case '{':
                return objeto();
            case '[':
                return arreglo();
            case '"':
                return cadena();
            case 't':
                literal("true");
                return Boolean.TRUE;
            case 'f':
                literal("false");
                return Boolean.FALSE;
            case 'n':
                literal("null");
                return null;
            default:
                return numero();
        }
    }

    private Map<String, Object> objeto() {
        Map<String, Object> m = new LinkedHashMap<>();
        i++; // '{'
        espacios();
        if (consumir('}')) {
            return m;
        }
        do {
            espacios();
            if (i >= s.length() || s.charAt(i) != '"') {
                throw error("Se esperaba una clave entre comillas");
            }
            String clave = cadena();
            espacios();
            if (!consumir(':')) {
                throw error("Se esperaba ':' después de la clave \"" + clave + "\"");
            }
            espacios();
            m.put(clave, valor());
            espacios();
        } while (consumir(','));
        if (!consumir('}')) {
            throw error("Se esperaba ',' o '}'");
        }
        return m;
    }

    private List<Object> arreglo() {
        List<Object> l = new ArrayList<>();
        i++; // '['
        espacios();
        if (consumir(']')) {
            return l;
        }
        do {
            espacios();
            l.add(valor());
            espacios();
        } while (consumir(','));
        if (!consumir(']')) {
            throw error("Se esperaba ',' o ']'");
        }
        return l;
    }

    private String cadena() {
        StringBuilder sb = new StringBuilder();
        i++; // comilla de apertura
        while (true) {
            if (i >= s.length()) {
                throw error("Cadena sin cerrar");
            }
            char c = s.charAt(i++);
            if (c == '"') {
                return sb.toString();
            }
            if (c == '\\') {
                if (i >= s.length()) {
                    throw error("Secuencia de escape incompleta");
                }
                char e = s.charAt(i++);
                switch (e) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (i + 4 > s.length()) {
                            throw error("Escape \\u incompleto");
                        }
                        try {
                            sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        } catch (NumberFormatException ex) {
                            throw error("Escape \\u inválido");
                        }
                        i += 4;
                        break;
                    default:
                        throw error("Escape desconocido: \\" + e);
                }
            } else if (c < 0x20) {
                throw error("Carácter de control sin escapar en cadena");
            } else {
                sb.append(c);
            }
        }
    }

    private Double numero() {
        int ini = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) {
            i++;
        }
        if (ini == i) {
            throw error("Valor JSON inesperado '" + s.charAt(i) + "'");
        }
        try {
            return Double.valueOf(s.substring(ini, i));
        } catch (NumberFormatException ex) {
            i = ini;
            throw error("Número inválido");
        }
    }

    private void literal(String esperado) {
        if (!s.startsWith(esperado, i)) {
            throw error("Se esperaba '" + esperado + "'");
        }
        i += esperado.length();
    }

    private boolean consumir(char c) {
        if (i < s.length() && s.charAt(i) == c) {
            i++;
            return true;
        }
        return false;
    }

    private void espacios() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                i++;
            } else {
                break;
            }
        }
    }

    private IllegalArgumentException error(String msg) {
        int linea = 1;
        int col = 1;
        for (int k = 0; k < Math.min(i, s.length()); k++) {
            if (s.charAt(k) == '\n') {
                linea++;
                col = 1;
            } else {
                col++;
            }
        }
        return new IllegalArgumentException("JSON inválido (línea " + linea + ", columna " + col + "): " + msg);
    }
}
