package consultora.red;

import static consultora.red.GrafosPrueba.aleatorio;
import static consultora.red.GrafosPrueba.esAciclicoKahn;
import static consultora.red.GrafosPrueba.grafo;
import static consultora.red.GrafosPrueba.set;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ComponentesYCiclosTest {

    // ---------- Componentes ----------

    @Test
    @DisplayName("componentes: dos comunidades, ordenadas de mayor a menor")
    void dosComponentes() {
        Grafo g = grafo("A>B", "B>C", "D>E");
        List<Set<String>> c = Componentes.encontrar(g);
        assertEquals(2, c.size());
        assertEquals(set("A", "B", "C"), new TreeSet<>(c.get(0)));
        assertEquals(set("D", "E"), new TreeSet<>(c.get(1)));
    }

    @Test
    @DisplayName("componentes: se ignora el sentido de las aristas")
    void ignoraSentido() {
        Grafo g = grafo("A>B", "C>B"); // A y C no se alcanzan en sentido dirigido, pero están conectados
        assertEquals(1, Componentes.encontrar(g).size());
    }

    @Test
    @DisplayName("componentes: nodos aislados forman su propia componente")
    void aislados() {
        Grafo g = grafo("A>B", "X", "Y");
        assertEquals(3, Componentes.encontrar(g).size());
    }

    @Test
    @DisplayName("componentes: red vacía y de un nodo")
    void vaciaYUnNodo() {
        assertTrue(Componentes.encontrar(new Grafo()).isEmpty());
        List<Set<String>> c = Componentes.encontrar(grafo("Solo"));
        assertEquals(1, c.size());
        assertEquals(set("Solo"), new TreeSet<>(c.get(0)));
    }

    @Test
    @DisplayName("componentes: las componentes particionan los nodos (aleatorio)")
    void particion() {
        Random rnd = new Random(7);
        for (int t = 0; t < 200; t++) {
            Grafo g = aleatorio(rnd, 1 + rnd.nextInt(12), 0.12, true);
            int suma = 0;
            Set<String> union = new TreeSet<>();
            for (Set<String> c : Componentes.encontrar(g)) {
                suma += c.size();
                union.addAll(c);
            }
            assertEquals(g.numNodos(), suma, "las componentes son disjuntas");
            assertEquals(new TreeSet<>(g.nodos()), union, "cubren todos los nodos");
        }
    }

    // ---------- Ciclos dirigidos ----------

    /** Un ciclo cerrado válido: primero = último y cada paso es una arista dirigida existente. */
    private static void assertCicloDirigidoValido(Grafo g, List<String> ciclo) {
        assertTrue(ciclo.size() >= 2);
        assertEquals(ciclo.get(0), ciclo.get(ciclo.size() - 1));
        for (int i = 0; i + 1 < ciclo.size(); i++) {
            assertTrue(g.contieneArista(ciclo.get(i), ciclo.get(i + 1)), "falta la arista " + ciclo.get(i) + ">" + ciclo.get(i + 1));
        }
    }

    @Test
    @DisplayName("ciclo dirigido: triángulo")
    void cicloTriangulo() {
        Grafo g = grafo("A>B", "B>C", "C>A");
        Optional<List<String>> c = Ciclos.cicloDirigido(g);
        assertTrue(c.isPresent());
        assertCicloDirigidoValido(g, c.get());
        assertEquals(4, c.get().size()); // 3 nodos + cierre
    }

    @Test
    @DisplayName("ciclo dirigido: auto-lazo es ciclo de longitud 1")
    void cicloAutoLazo() {
        Optional<List<String>> c = Ciclos.cicloDirigido(grafo("A>A"));
        assertEquals(Optional.of(List.of("A", "A")), c);
    }

    @Test
    @DisplayName("ciclo dirigido: arista mutua es ciclo de longitud 2")
    void cicloMutuo() {
        Grafo g = grafo("A>B", "B>A");
        Optional<List<String>> c = Ciclos.cicloDirigido(g);
        assertTrue(c.isPresent());
        assertCicloDirigidoValido(g, c.get());
    }

    @Test
    @DisplayName("ciclo dirigido: un rombo (DAG) no tiene ciclo aunque haya dos rutas")
    void rombo() {
        assertTrue(Ciclos.cicloDirigido(grafo("A>B", "A>C", "B>D", "C>D")).isEmpty());
    }

    @Test
    @DisplayName("ciclo dirigido: se encuentra en una componente que no es la primera")
    void cicloEnSegundaComponente() {
        Grafo g = grafo("A>B", "X>Y", "Y>Z", "Z>X");
        Optional<List<String>> c = Ciclos.cicloDirigido(g);
        assertTrue(c.isPresent());
        assertCicloDirigidoValido(g, c.get());
    }

    @Test
    @DisplayName("ciclo dirigido: coincide con el algoritmo de Kahn en grafos aleatorios")
    void cicloDirigidoContraKahn() {
        Random rnd = new Random(42);
        for (int t = 0; t < 500; t++) {
            Grafo g = aleatorio(rnd, 1 + rnd.nextInt(10), 0.1 + rnd.nextDouble() * 0.15, true);
            Optional<List<String>> c = Ciclos.cicloDirigido(g);
            assertEquals(esAciclicoKahn(g), c.isEmpty(), "discrepancia en " + g);
            c.ifPresent(x -> assertCicloDirigidoValido(g, x));
        }
    }

    @Test
    @DisplayName("ciclo dirigido: una cadena de 100 000 nodos no desborda la pila (DFS iterativo)")
    void cadenaLarga() {
        Grafo g = new Grafo();
        for (int i = 0; i < 100_000; i++) {
            g.agregarArista("n" + i, "n" + (i + 1));
        }
        assertTrue(Ciclos.cicloDirigido(g).isEmpty());
        assertTrue(Ciclos.cicloNoDirigido(g).isEmpty());
        g.agregarArista("n100000", "n0");
        assertTrue(Ciclos.cicloDirigido(g).isPresent());
        assertTrue(Ciclos.cicloNoDirigido(g).isPresent());
    }

    // ---------- Ciclos no dirigidos ----------

    @Test
    @DisplayName("ciclo no dirigido: un rombo sí tiene ciclo (aunque el dirigido no)")
    void cicloNoDirigidoRombo() {
        Grafo g = grafo("A>B", "A>C", "B>D", "C>D");
        Optional<List<String>> c = Ciclos.cicloNoDirigido(g);
        assertTrue(c.isPresent());
        List<String> ciclo = c.get();
        assertEquals(5, ciclo.size()); // 4 nodos + cierre
        assertEquals(ciclo.get(0), ciclo.get(4));
        for (int i = 0; i < 4; i++) {
            assertTrue(g.vecinos(ciclo.get(i)).contains(ciclo.get(i + 1)));
        }
    }

    @Test
    @DisplayName("ciclo no dirigido: la arista mutua A>B,B>A NO es ciclo (se colapsa)")
    void mutuaNoEsCicloNoDirigido() {
        Grafo g = grafo("A>B", "B>A");
        assertTrue(Ciclos.cicloNoDirigido(g).isEmpty());
        assertTrue(Ciclos.cicloDirigido(g).isPresent());
    }

    @Test
    @DisplayName("ciclo no dirigido: auto-lazo cuenta como ciclo")
    void autoLazoNoDirigido() {
        assertEquals(Optional.of(List.of("B", "B")), Ciclos.cicloNoDirigido(grafo("A>B", "B>B")));
    }

    @Test
    @DisplayName("ciclo no dirigido: árbol y bosque no tienen ciclo")
    void arbolSinCiclo() {
        assertTrue(Ciclos.cicloNoDirigido(grafo("B>A", "C>A", "D>B", "E>B")).isEmpty());
        assertTrue(Ciclos.cicloNoDirigido(grafo("B>A", "D>C", "Z")).isEmpty());
    }

    @Test
    @DisplayName("ciclo no dirigido: equivale a E > V - C en la vista simple (aleatorio)")
    void cicloNoDirigidoContraFormula() {
        Random rnd = new Random(99);
        for (int t = 0; t < 500; t++) {
            Grafo g = aleatorio(rnd, 1 + rnd.nextInt(10), 0.05 + rnd.nextDouble() * 0.2, true);
            int comps = Componentes.encontrar(g).size();
            boolean esperado = !g.autoLazos().isEmpty() || g.numAristasNoDirigidas() > g.numNodos() - comps;
            assertEquals(esperado, Ciclos.cicloNoDirigido(g).isPresent(), "discrepancia en " + g);
        }
    }

    @Test
    @DisplayName("ciclos: red vacía y de un nodo sin ciclos")
    void ciclosVaciaYUnNodo() {
        assertFalse(Ciclos.cicloDirigido(new Grafo()).isPresent());
        assertFalse(Ciclos.cicloNoDirigido(new Grafo()).isPresent());
        assertFalse(Ciclos.cicloDirigido(grafo("Solo")).isPresent());
        assertFalse(Ciclos.cicloNoDirigido(grafo("Solo")).isPresent());
    }
}
