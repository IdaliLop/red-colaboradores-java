package consultora.red;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Grafo dirigido con pesos unitarios representado con listas de adyacencia.
 *
 * <p><b>Decisión de modelado.</b> Se almacena únicamente el grafo dirigido, pero en
 * <em>dos</em> mapas: sucesores (aristas de salida) y predecesores (aristas de entrada).
 * Esto permite obtener grados de entrada/salida y recorrer en ambos sentidos en O(1)
 * por nodo. La vista <em>no dirigida</em> (necesaria para componentes conexas y puntos de
 * articulación) se <b>deriva</b> bajo demanda como la unión sucesores ∪ predecesores, se
 * guarda en caché y se invalida en cuanto el grafo cambia. Así existe una sola fuente de
 * verdad y no hay riesgo de que ambas vistas se desincronicen.</p>
 *
 * <p>Convención: la arista {@code u → v} significa «u reporta a v» (u depende de v).</p>
 *
 * <p>Se usan {@link LinkedHashMap}/{@link LinkedHashSet} (subclases de {@code HashMap} y
 * {@code HashSet}, con las mismas complejidades O(1) esperadas) para que el orden de
 * iteración sea el de inserción y, por tanto, la salida sea determinista y reproducible.</p>
 *
 * <p>Las aristas repetidas se ignoran (grafo simple dirigido); los auto-lazos
 * {@code u → u} están permitidos en la vista dirigida y se descartan en la vista no
 * dirigida (no afectan conectividad ni articulación).</p>
 */
public final class Grafo {

    private final Map<String, Set<String>> sucesores = new LinkedHashMap<>();
    private final Map<String, Set<String>> predecesores = new LinkedHashMap<>();
    private Map<String, Set<String>> vistaNoDirigida; // caché; null = invalidada
    private int numAristas;

    /**
     * Agrega un nodo si no existe.
     *
     * @param id identificador del colaborador (no nulo ni en blanco)
     * @return {@code true} si el nodo era nuevo
     * @throws IllegalArgumentException si el identificador es nulo o está en blanco
     */
    public boolean agregarNodo(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("El identificador de un nodo no puede ser nulo ni vacío");
        }
        if (sucesores.containsKey(id)) {
            return false;
        }
        sucesores.put(id, new LinkedHashSet<>());
        predecesores.put(id, new LinkedHashSet<>());
        vistaNoDirigida = null;
        return true;
    }

    /**
     * Agrega la arista dirigida {@code origen → destino}, creando los nodos si faltan.
     *
     * @param origen  colaborador que reporta
     * @param destino colaborador al que se reporta
     * @return {@code true} si la arista era nueva
     */
    public boolean agregarArista(String origen, String destino) {
        agregarNodo(origen);
        agregarNodo(destino);
        boolean nueva = sucesores.get(origen).add(destino);
        if (nueva) {
            predecesores.get(destino).add(origen);
            numAristas++;
            vistaNoDirigida = null;
        }
        return nueva;
    }

    /**
     * @param id identificador del nodo
     * @return {@code true} si el nodo existe
     */
    public boolean contieneNodo(String id) {
        return sucesores.containsKey(id);
    }

    /**
     * @param origen  nodo origen
     * @param destino nodo destino
     * @return {@code true} si existe la arista dirigida {@code origen → destino}
     */
    public boolean contieneArista(String origen, String destino) {
        Set<String> s = sucesores.get(origen);
        return s != null && s.contains(destino);
    }

    /** @return vista de solo lectura de los nodos, en orden de inserción */
    public Set<String> nodos() {
        return Collections.unmodifiableSet(sucesores.keySet());
    }

    /**
     * @param v nodo
     * @return nodos a los que {@code v} reporta (aristas de salida)
     * @throws IllegalArgumentException si el nodo no existe
     */
    public Set<String> sucesores(String v) {
        return Collections.unmodifiableSet(requerir(sucesores, v));
    }

    /**
     * @param v nodo
     * @return nodos que reportan a {@code v} (aristas de entrada)
     * @throws IllegalArgumentException si el nodo no existe
     */
    public Set<String> predecesores(String v) {
        return Collections.unmodifiableSet(requerir(predecesores, v));
    }

    /**
     * Vecinos en la vista no dirigida derivada (sucesores ∪ predecesores, sin auto-lazo).
     *
     * @param v nodo
     * @return vecinos de {@code v}
     * @throws IllegalArgumentException si el nodo no existe
     */
    public Set<String> vecinos(String v) {
        return Collections.unmodifiableSet(requerir(vistaNoDirigida(), v));
    }

    /** @return número de nodos |V| */
    public int numNodos() {
        return sucesores.size();
    }

    /** @return número de aristas dirigidas |E| (incluye auto-lazos) */
    public int numAristas() {
        return numAristas;
    }

    /**
     * @return número de aristas de la vista no dirigida: pares {u,v} con u≠v tales que
     *         existe u→v o v→u (una arista mutua cuenta una sola vez)
     */
    public int numAristasNoDirigidas() {
        int suma = 0;
        for (Set<String> s : vistaNoDirigida().values()) {
            suma += s.size();
        }
        return suma / 2;
    }

    /**
     * @param v nodo
     * @return {@code true} si {@code v} tiene un auto-lazo {@code v → v}
     */
    public boolean tieneAutoLazo(String v) {
        return requerir(sucesores, v).contains(v);
    }

    /** @return nodos con auto-lazo, en orden de inserción */
    public List<String> autoLazos() {
        List<String> r = new ArrayList<>();
        for (Map.Entry<String, Set<String>> e : sucesores.entrySet()) {
            if (e.getValue().contains(e.getKey())) {
                r.add(e.getKey());
            }
        }
        return r;
    }

    /** @return {@code true} si no hay nodos */
    public boolean estaVacio() {
        return sucesores.isEmpty();
    }

    private Map<String, Set<String>> vistaNoDirigida() {
        if (vistaNoDirigida == null) {
            Map<String, Set<String>> m = new LinkedHashMap<>();
            for (String v : sucesores.keySet()) {
                m.put(v, new LinkedHashSet<>());
            }
            for (Map.Entry<String, Set<String>> e : sucesores.entrySet()) {
                String u = e.getKey();
                for (String w : e.getValue()) {
                    if (!u.equals(w)) {
                        m.get(u).add(w);
                        m.get(w).add(u);
                    }
                }
            }
            vistaNoDirigida = m;
        }
        return vistaNoDirigida;
    }

    private static Set<String> requerir(Map<String, Set<String>> mapa, String v) {
        Set<String> s = mapa.get(v);
        if (s == null) {
            throw new IllegalArgumentException("El nodo no existe en la red: " + v);
        }
        return s;
    }

    @Override
    public String toString() {
        return "Grafo[nodos=" + numNodos() + ", aristas=" + numAristas + "]";
    }
}
