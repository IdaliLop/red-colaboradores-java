package consultora.red;

import static consultora.red.GrafosPrueba.grafo;
import static consultora.red.GrafosPrueba.set;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.TreeSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Los seis escenarios exigidos por el examen, verificados de extremo a extremo con
 * {@link AnalisisRed} y {@link Reporte}.
 */
class CasosBordeTest {

    @Test
    @DisplayName("1. Grafo con ciclo")
    void grafoConCiclo() {
        AnalisisRed a = AnalisisRed.analizar(grafo("A>B", "B>C", "C>A", "D>A"));
        assertEquals(1, a.componentes().size());
        assertTrue(a.cicloDirigido().isPresent());
        assertTrue(a.cicloNoDirigido().isPresent());
        assertEquals(set("A"), new TreeSet<>(a.puntosArticulacion()));
        assertEquals(new Grados.GradoNodo("A", 2, 1), a.grados().get(0));
    }

    @Test
    @DisplayName("2. Grafo en árbol")
    void grafoArbol() {
        AnalisisRed a = AnalisisRed.analizar(grafo("B>A", "C>A", "D>B", "E>B"));
        assertEquals(1, a.componentes().size());
        assertEquals(5, a.componentes().get(0).size());
        assertTrue(a.cicloDirigido().isEmpty());
        assertTrue(a.cicloNoDirigido().isEmpty());
        assertEquals(set("A", "B"), new TreeSet<>(a.puntosArticulacion()));
        assertEquals(a.grafo().numNodos() - 1, a.grafo().numAristasNoDirigidas()); // |E| = |V| - 1
    }

    @Test
    @DisplayName("3. Grafo con 2 componentes")
    void dosComponentes() {
        AnalisisRed a = AnalisisRed.analizar(grafo("A>B", "B>C", "D>E"));
        assertEquals(2, a.componentes().size());
        assertEquals(3, a.componentes().get(0).size());
        assertEquals(2, a.componentes().get(1).size());
        assertTrue(a.cicloDirigido().isEmpty());
        assertEquals(set("B"), new TreeSet<>(a.puntosArticulacion()));
    }

    @Test
    @DisplayName("4. Red de 1 nodo")
    void unNodo() {
        AnalisisRed a = AnalisisRed.analizar(grafo("Solo"));
        assertEquals(1, a.componentes().size());
        assertTrue(a.cicloDirigido().isEmpty());
        assertTrue(a.cicloNoDirigido().isEmpty());
        assertEquals(List.of(new Grados.GradoNodo("Solo", 0, 0)), a.grados());
        assertTrue(a.puntosArticulacion().isEmpty());
        assertEquals(0, CaminoMasLargo.buscar(a.grafo(), "Solo", "Solo", true).orElseThrow().aristas());
    }

    @Test
    @DisplayName("5. Red vacía")
    void redVacia() {
        AnalisisRed a = AnalisisRed.analizar(new Grafo());
        assertTrue(a.componentes().isEmpty());
        assertTrue(a.cicloDirigido().isEmpty());
        assertTrue(a.cicloNoDirigido().isEmpty());
        assertTrue(a.grados().isEmpty());
        assertTrue(a.puntosArticulacion().isEmpty());
        String texto = Reporte.generar("(vacía)", a, List.of()); // no debe lanzar excepción
        assertTrue(texto.contains("la red está vacía"));
        assertTrue(texto.contains("Nodos           : 0"));
    }

    @Test
    @DisplayName("6. Red con auto-lazo")
    void autoLazo() {
        AnalisisRed a = AnalisisRed.analizar(grafo("A>A", "A>B"));
        assertEquals(List.of("A", "A"), a.cicloDirigido().orElseThrow());
        assertEquals(List.of("A", "A"), a.cicloNoDirigido().orElseThrow());
        assertEquals(1, a.componentes().size());
        assertEquals(new Grados.GradoNodo("A", 1, 2), a.grados().get(0));
        assertTrue(a.puntosArticulacion().isEmpty());
        assertTrue(Reporte.generar("t", a, List.of()).contains("Auto-lazos"));
    }

    // ---------- RF6: salida tabulada y exportación ----------

    @Test
    @DisplayName("el reporte contiene las 5 secciones y las tablas")
    void reporteCompleto() {
        AnalisisRed a = AnalisisRed.analizar(grafo("A>B", "B>C", "C>A", "D>A", "X"));
        String t = Reporte.generar("prueba", a, List.of(new Reporte.Par("D", "C")));
        for (String sec : new String[] {"1. COMUNIDADES", "2. DETECCIÓN", "3. GRADO", "4. CAMINO", "5. COLABORADORES PUENTE"}) {
            assertTrue(t.contains(sec), "falta la sección " + sec);
        }
        assertTrue(t.contains("| Colaborador | Entrada | Salida | Total |"));
        assertTrue(t.contains("JERARQUÍA INVÁLIDA"));
        assertFalse(t.contains("\r"), "debe usar solo \\n para ser idéntico en cualquier SO");
    }

    @Test
    @DisplayName("exportar escribe exactamente el mismo texto en UTF-8 (crea directorios)")
    void exportar() throws IOException {
        AnalisisRed a = AnalisisRed.analizar(grafo("Óscar>Ñoño"));
        String t = Reporte.generar("prueba", a, List.of());
        Path dir = Files.createTempDirectory("rep");
        Path destino = dir.resolve("sub").resolve("resultados.txt");
        try {
            Reporte.exportar(t, destino);
            assertEquals(t, Files.readString(destino, StandardCharsets.UTF_8));
        } finally {
            Files.deleteIfExists(destino);
            Files.deleteIfExists(destino.getParent());
            Files.deleteIfExists(dir);
        }
    }

    @Test
    @DisplayName("un par con nodo inexistente produce IllegalArgumentException")
    void parInvalido() {
        AnalisisRed a = AnalisisRed.analizar(grafo("A>B"));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
                () -> Reporte.generar("t", a, List.of(new Reporte.Par("A", "Z"))));
    }
}
