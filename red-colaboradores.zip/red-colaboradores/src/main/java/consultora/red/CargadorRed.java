package consultora.red;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Carga una red de colaboradores desde {@code red.json} o {@code red.csv} (RF1).
 *
 * <h2>Formato elegido</h2>
 * <p><b>JSON es el formato principal</b> porque (a) representa de forma natural los nodos
 * aislados (lista {@code "nodos"}), imprescindibles para los casos «red de 1 nodo» y
 * «2 componentes»; (b) es autodescriptivo y extensible (se pueden añadir atributos sin
 * romper el parser); y (c) distingue explícitamente nodos de aristas. Su desventaja, un
 * parser más largo, se resuelve con {@link JsonMinimo} (≈200 líneas, O(n)).</p>
 * <p><b>CSV también se soporta</b> por ser trivial de producir desde una hoja de cálculo.
 * Es una lista de aristas {@code origen,destino}; una fila con un solo valor (o destino
 * vacío) declara un nodo aislado.</p>
 *
 * <h2>Esquemas</h2>
 * <pre>
 * {"nodos": ["Ana","Beto"], "aristas": [{"origen":"Beto","destino":"Ana"}]}
 *
 * origen,destino      (encabezado opcional; '#' inicia comentario)
 * Beto,Ana
 * Paula,              (nodo aislado)
 * </pre>
 * <p>Si una arista menciona un nodo no declarado, el nodo se crea automáticamente.</p>
 */
public final class CargadorRed {

    private CargadorRed() {
    }

    /**
     * Carga el archivo eligiendo el parser por extensión ({@code .json} o {@code .csv}).
     *
     * @param ruta ruta del archivo
     * @return grafo cargado
     * @throws IOException              si no se puede leer el archivo
     * @throws IllegalArgumentException si la extensión no es soportada o el contenido es inválido
     */
    public static Grafo cargar(Path ruta) throws IOException {
        String nombre = ruta.getFileName().toString().toLowerCase(Locale.ROOT);
        if (!nombre.endsWith(".json") && !nombre.endsWith(".csv")) {
            throw new IllegalArgumentException("Extensión no soportada (use .json o .csv): " + ruta);
        }
        String texto = Files.readString(ruta, StandardCharsets.UTF_8);
        return nombre.endsWith(".json") ? desdeJson(texto) : desdeCsv(texto);
    }

    /**
     * Construye el grafo a partir de texto JSON.
     *
     * @param texto documento JSON con las claves opcionales {@code nodos} y {@code aristas}
     * @return grafo resultante (vacío si el objeto está vacío)
     * @throws IllegalArgumentException si el JSON o su esquema son inválidos
     */
    public static Grafo desdeJson(String texto) {
        Object raiz = JsonMinimo.parsear(quitarBom(texto));
        if (!(raiz instanceof Map)) {
            throw new IllegalArgumentException("La raíz del JSON debe ser un objeto");
        }
        Map<?, ?> obj = (Map<?, ?>) raiz;
        Grafo g = new Grafo();

        Object nodos = obj.get("nodos");
        if (nodos != null) {
            if (!(nodos instanceof List)) {
                throw new IllegalArgumentException("\"nodos\" debe ser un arreglo de cadenas");
            }
            for (Object n : (List<?>) nodos) {
                if (!(n instanceof String)) {
                    throw new IllegalArgumentException("Cada elemento de \"nodos\" debe ser una cadena");
                }
                g.agregarNodo(((String) n).trim());
            }
        }

        Object aristas = obj.get("aristas");
        if (aristas != null) {
            if (!(aristas instanceof List)) {
                throw new IllegalArgumentException("\"aristas\" debe ser un arreglo de objetos");
            }
            int k = 0;
            for (Object a : (List<?>) aristas) {
                k++;
                if (!(a instanceof Map)) {
                    throw new IllegalArgumentException("La arista #" + k + " debe ser un objeto");
                }
                Object o = ((Map<?, ?>) a).get("origen");
                Object d = ((Map<?, ?>) a).get("destino");
                if (!(o instanceof String) || !(d instanceof String)) {
                    throw new IllegalArgumentException(
                            "La arista #" + k + " requiere \"origen\" y \"destino\" como cadenas");
                }
                g.agregarArista(((String) o).trim(), ((String) d).trim());
            }
        }
        return g;
    }

    /**
     * Construye el grafo a partir de texto CSV.
     *
     * @param texto filas {@code origen,destino}; admite encabezado, comentarios '#',
     *              campos entre comillas y filas de nodo aislado
     * @return grafo resultante (vacío si no hay filas de datos)
     * @throws IllegalArgumentException si alguna fila es inválida
     */
    public static Grafo desdeCsv(String texto) {
        Grafo g = new Grafo();
        String[] lineas = quitarBom(texto).split("\\R", -1);
        boolean primeraFilaDatos = true;
        for (int n = 0; n < lineas.length; n++) {
            String linea = lineas[n].strip();
            if (linea.isEmpty() || linea.startsWith("#")) {
                continue;
            }
            List<String> c = dividirCsv(linea, n + 1);
            if (primeraFilaDatos) {
                primeraFilaDatos = false;
                if (c.size() >= 2 && c.get(0).equalsIgnoreCase("origen")
                        && c.get(1).equalsIgnoreCase("destino")) {
                    continue; // encabezado
                }
            }
            if (c.size() > 2) {
                throw new IllegalArgumentException("CSV línea " + (n + 1) + ": se esperaban 1 o 2 columnas");
            }
            String origen = c.get(0);
            if (origen.isEmpty()) {
                throw new IllegalArgumentException("CSV línea " + (n + 1) + ": 'origen' vacío");
            }
            if (c.size() == 1 || c.get(1).isEmpty()) {
                g.agregarNodo(origen);
            } else {
                g.agregarArista(origen, c.get(1));
            }
        }
        return g;
    }

    /** Divide una línea CSV respetando comillas dobles y {@code ""} como comilla literal. */
    private static List<String> dividirCsv(String linea, int numLinea) {
        List<String> campos = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean entreComillas = false;
        for (int i = 0; i < linea.length(); i++) {
            char ch = linea.charAt(i);
            if (entreComillas) {
                if (ch == '"') {
                    if (i + 1 < linea.length() && linea.charAt(i + 1) == '"') {
                        sb.append('"');
                        i++;
                    } else {
                        entreComillas = false;
                    }
                } else {
                    sb.append(ch);
                }
            } else if (ch == '"') {
                entreComillas = true;
            } else if (ch == ',') {
                campos.add(sb.toString().strip());
                sb.setLength(0);
            } else {
                sb.append(ch);
            }
        }
        if (entreComillas) {
            throw new IllegalArgumentException("CSV línea " + numLinea + ": comillas sin cerrar");
        }
        campos.add(sb.toString().strip());
        return campos;
    }

    private static String quitarBom(String t) {
        return (!t.isEmpty() && t.charAt(0) == '\uFEFF') ? t.substring(1) : t;
    }
}
