# Análisis de la red de colaboradores

Examen práctico – Segundo parcial – Estructuras de Datos y Algoritmia.
Herramienta en **Java 17+** (solo `java.util`, sin librerías de grafos) que analiza una red de
colaboradores modelada como grafo.

| Punto del caso | Qué hace | Clase | Algoritmo | Tiempo |
|---|---|---|---|---|
| 1 | Comunidades aisladas | `Componentes` | BFS (`ArrayDeque`) | O(V+E) |
| 2 | Ciclos / jerarquías inválidas | `Ciclos` | DFS iterativo, 3 colores (dirigido) y padre (no dirigido) | O(V+E) |
| 3a | Grado de entrada / salida | `Grados` | Listas de adyacencia | O(V+E) |
| 3b | Camino simple más largo | `CaminoMasLargo` | Backtracking + poda por alcanzabilidad (NP-difícil) | O(n!·(V+E)) peor caso |
| 4 | Colaboradores puente | `PuntosArticulacion` | Tarjan (disc/low), iterativo | O(V+E) |

## Estructura

```
├── pom.xml
├── README.md
├── reporte.pdf                  Reporte técnico
├── resultados.txt               Salida de ejemplo (16 nodos)
├── data/
│   ├── red.json                 Red de ejemplo (formato principal)
│   └── red.csv                  La misma red en CSV
└── src/
    ├── main/java/consultora/red/
    │   ├── Grafo.java               Modelo (dirigido + vista no dirigida derivada)
    │   ├── JsonMinimo.java          Parser JSON propio (RF1)
    │   ├── CargadorRed.java         Carga .json / .csv (RF1)
    │   ├── Componentes.java         BFS (RF2)
    │   ├── Ciclos.java              DFS (RF2)
    │   ├── Grados.java              (RF3)
    │   ├── CaminoMasLargo.java      (RF4)
    │   ├── PuntosArticulacion.java  (RF5)
    │   ├── AnalisisRed.java         Fachada de análisis
    │   ├── Reporte.java             Tablas + exportación (RF6)
    │   └── Main.java
    └── test/java/consultora/red/    74 pruebas JUnit 5
```

## Requisitos

* JDK 17 o superior
* Maven 3.8+ (solo para compilar y ejecutar las pruebas; descarga JUnit 5 en alcance `test`)

## Compilar y probar

```bash
mvn clean test
```

## Ejecutar

```bash
mvn -q package -DskipTests

java -cp target/classes consultora.red.Main data/red.json \
     --par Hugo Ana --par Irene Fabián --par Paula Ana
```

Argumentos (todos opcionales):

| Argumento | Significado | Por defecto |
|---|---|---|
| `archivo` | `.json` o `.csv` de entrada | `data/red.json` |
| `-o salida` | archivo de resultados | `resultados.txt` |
| `--par ORIGEN DESTINO` | calcula el camino simple más largo entre ambos (repetible) | ninguno |

La salida se imprime en consola y se escribe idéntica en `resultados.txt`.

> **Windows:** si los acentos se ven mal en `cmd`, ejecute `chcp 65001` antes. En Linux/macOS,
> si los argumentos con acentos (p. ej. `Fabián`) no se reconocen, use un locale UTF-8
> (`export LC_ALL=C.UTF-8`).

## Formato de datos

**Convención:** la arista `A → B` significa «A reporta a B».

`red.json` (formato principal; admite nodos aislados):

```json
{
  "nodos":   ["Ana", "Beto", "Paula"],
  "aristas": [ {"origen": "Beto", "destino": "Ana"} ]
}
```

`red.csv` (una arista por fila; una fila con un solo valor declara un nodo aislado):

```csv
origen,destino
Beto,Ana
Paula,
```

Las aristas que mencionan nodos no declarados los crean automáticamente. Las aristas repetidas
se ignoran.

## Decisiones de diseño (resumen; detalle en `reporte.pdf`)

* **Grafo dirigido + vista no dirigida derivada.** Se guardan sucesores y predecesores; la vista
  no dirigida (sucesores ∪ predecesores) se calcula bajo demanda y se invalida al modificar el
  grafo. Una sola fuente de verdad.
* **Auto-lazo** `A → A`: ciclo de longitud 1 (dirigido y no dirigido); suma 1 al grado de entrada
  y 1 al de salida; no afecta conectividad ni puntos de articulación.
* **Arista mutua** `A → B` y `B → A`: ciclo de longitud 2 en el grafo dirigido (jerarquía
  inválida), pero **no** es ciclo en la vista no dirigida (se colapsa en una sola arista).
* **`ArrayDeque`** para cola (BFS) y pila (DFS): sin sincronización ni herencia de `Vector`
  (`Stack`), y sin un nodo por elemento (`LinkedList`).
* **DFS iterativo**: redes profundas (se prueba una cadena de 100 000 nodos) no desbordan la pila.
* **Camino más largo**: NP-difícil. Poda: `longitud_actual + |R| ≤ mejor`, con `R` = nodos no
  visitados alcanzables desde el nodo actual. La poda se valida contra búsqueda exhaustiva.

## Pruebas

74 pruebas JUnit 5. Cubren los seis escenarios pedidos (`CasosBordeTest`): grafo con ciclo, árbol,
2 componentes, red de 1 nodo, red vacía y red con auto-lazo. Además hay pruebas contra
**oráculos independientes** sobre miles de grafos aleatorios con semilla fija: algoritmo de Kahn
(ciclos dirigidos), fórmula `E > V − C` (ciclos no dirigidos), búsqueda exhaustiva sin poda
(camino más largo), programación dinámica en DAG y definición por eliminación de nodo (Tarjan).

## Referencias y código de terceros

Todo el código fuente es de autoría propia; **no se usó código de terceros**. Los algoritmos
provienen de la literatura:

1. Cormen, Leiserson, Rivest, Stein. *Introduction to Algorithms*, 4.ª ed. MIT Press, 2022
   (BFS, DFS, clasificación de aristas, componentes).
2. R. E. Tarjan. «Depth-first search and linear graph algorithms». *SIAM J. Computing* 1(2), 1972.
3. J. Hopcroft, R. Tarjan. «Algorithm 447: efficient algorithms for graph manipulation».
   *Commun. ACM* 16(6), 1973 (puntos de articulación).
4. M. R. Garey, D. S. Johnson. *Computers and Intractability*, 1979 (camino hamiltoniano / camino
   simple más largo, NP-completo).
5. A. B. Kahn. «Topological sorting of large networks». *Commun. ACM* 5(11), 1962 (oráculo de pruebas).
6. Oracle. *Java SE 17 API*: `java.util.ArrayDeque`, `java.util.Stack`, `java.util.LinkedList`.
7. T. Bray (ed.). *RFC 8259: The JSON Data Interchange Format*, 2017.
